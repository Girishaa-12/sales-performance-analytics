# 📊 Sales Performance Analytics Dashboard

[![Python](https://img.shields.io/badge/Python-3.11%2B-blue.svg)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.40%2B-FF4B4B.svg)](https://streamlit.io/)
[![Plotly](https://img.shields.io/badge/Plotly-5.24%2B-3F4F75.svg)](https://plotly.com/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0%2B-4479A1.svg)](https://www.mysql.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

An intermediate-level, production-grade enterprise Data Analytics and Business Intelligence application designed to monitor sales performance, dissect multi-year revenue and profitability drivers, quantify discount elasticity, and surface actionable merchandising recommendations.

---

## 📌 Table of Contents
- [Project Overview](#-project-overview)
- [Problem Statement](#-problem-statement)
- [Objectives](#-objectives)
- [Key Features](#-key-features)
- [Technologies Used](#-technologies-used)
- [Dataset Architecture](#-dataset-architecture)
- [Data Cleaning Pipeline](#-data-cleaning-pipeline)
- [Feature Engineering](#-feature-engineering)
- [Intermediate SQL Analysis](#-intermediate-sql-analysis)
- [Dashboard Architecture & UI](#-dashboard-architecture--ui)
- [Project Structure](#-project-structure)
- [Installation & Setup](#-installation--setup)
- [MySQL Configuration](#-mysql-configuration)
- [Running the Application](#-running-the-application)
- [Automated Testing](#-automated-testing)
- [Dynamic Business Insights](#-dynamic-business-insights)
- [Project Limitations](#-project-limitations)
- [Future Enhancements](#-future-enhancements)
- [Learning Outcomes](#-learning-outcomes)

---

## 🌟 Project Overview
In competitive modern e-commerce and retail supply chains, leadership teams struggle with information silos, margin compression from unmonitored discounting, and lagged visibility into territory growth. 

This project provides an interactive **Executive Sales Performance Analytics Platform** built with **Python, Pandas, MySQL, Plotly, and Streamlit**. It transitions transactional data into real-time decision support, tracking metrics such as **Sales Growth %, Profit Margin %, Average Order Value (AOV), and Discount-to-Margin Elasticity**.

---

## 🎯 Problem Statement
A multi-regional commercial enterprise operating across 4 major territories (North, South, East, West) and 3 primary categories (Technology, Furniture, Office Supplies) needs to:
1. **Diagnose Sales Velocity**: Identify seasonality spikes, peak transaction months, and Year-over-Year / Month-over-Month growth rates.
2. **Mitigate Margin Erosion**: Detect transactions where heavy promotional discounts (>20%) push net profitability into negative territory.
3. **Optimize Territory Resource Allocation**: Discern leading vs. underperforming states and cities.
4. **Identify Customer Value Tiers**: Segment frequent shoppers and high-AOV customers for targeted retention.

---

## 🏆 Objectives
- Construct an automated data preparation pipeline handling dirty dates, missing values, duplicates, and type validation.
- Engineer derived temporal and financial indicators (`Profit_Margin`, `Sales_Per_Unit`, `Quarter`).
- Write 17 intermediate SQL queries demonstrating aggregations, CTEs, and window functions (`LAG() OVER()`).
- Deploy an interactive 7-tab Streamlit dashboard with reactive filtering and custom enterprise styling.
- Deliver automated unit tests and an exploratory data analysis Jupyter notebook.

---

## 🚀 Key Features
- **⚡ Reactive Sidebar Filtering**: Filter synchronously across Date Range, Region, Cascading State, Category, Product, and Payment Mode, with a one-click `🔄 Reset Filters` controller.
- **📈 Dynamic Period-over-Period KPI Cards**: Computes Total Sales, Total Profit, Orders, Quantity, AOV, and Profit Margin with live delta percentage comparisons.
- **📉 Discount vs. Profit Scatter (Margin Erosion)**: Interactive Plotly chart with break-even zero-profit reference lines, illustrating where discounts destroy margins.
- **🏆 Dynamic Product & Customer Leaderboards**: Rank top/bottom performers dynamically by Sales, Profit, or Quantity Sold.
- **💡 Algorithmic Business Insights Engine**: Automatically computes the best/weakest regions, star products, loss-makers, and tactical recommendations from current filtered slices (zero hardcoding).
- **📋 Data Explorer & Export**: Interactive grid with search filtering and direct CSV data export.

---

## 🛠️ Technologies Used
| Technology | Role |
|---|---|
| **Python 3.11+** | Core programming language |
| **Pandas** | Data wrangling, aggregations, pivoting, and feature engineering |
| **NumPy** | Vectorized mathematical operations and conditional margin logic |
| **MySQL 8.0** | Relational storage, indexing, and intermediate analytical SQL queries |
| **Plotly Express & Graph Objects** | Publication-quality interactive data visualizations |
| **Streamlit** | Modern reactive web dashboard and interactive UI |
| **python-dotenv** | Secure environment variable management |
| **pytest** | Automated unit test suite |

---

## 📦 Dataset Architecture
The project utilizes a multi-year synthetic dataset (`data/raw_sales_data.csv` and `data/sales_data.csv`) comprising **7,300+ records** spanning **2022 to 2025**.

### Schema Definition:
| Column Name | Data Type | Description |
|---|---|---|
| `Order_ID` | String | Unique transaction identifier (e.g. `ORD-2024-10245`) |
| `Order_Date` | Date / Datetime | Transaction timestamp (`YYYY-MM-DD`) |
| `Customer_ID` | String | Unique customer identifier (`CUST-10001` to `CUST-10550`) |
| `Customer_Name`| String | Full name of the customer |
| `Product` | String | Commercial product catalog name (40 distinct SKUs) |
| `Category` | String | High-level category (`Technology`, `Furniture`, `Office Supplies`) |
| `Sub_Category` | String | Sub-department (`Laptops`, `Phones`, `Chairs`, `Storage`, etc.) |
| `Region` | String | Operating territory (`North`, `South`, `East`, `West`) |
| `State` | String | State jurisdiction (25+ states) |
| `City` | String | Municipal territory (Chicago, NYC, Austin, etc.) |
| `Sales` | Float | Net monetary revenue ($) after discount |
| `Quantity` | Integer | Units fulfilled per line item |
| `Discount` | Float | Promotional discount percentage (0.0 to 0.50) |
| `Profit` | Float | Net profit realized ($) after procurement and overhead |
| `Payment_Mode` | String | Payment channel (`Credit Card`, `Debit Card`, `UPI`, `COD`) |

---

## 🧹 Data Cleaning Pipeline
Implemented in `src/data_cleaning.py`, the pipeline enforces rigorous real-world data hygiene:
1. **Duplicate Detection & Removal**: Removes exact duplicated records.
2. **Missing-Value Imputation**: 
   - Drops records missing essential primary keys (`Order_ID`, `Sales`, `Profit`).
   - Imputes non-critical categoricals (`Payment_Mode`) using statistical mode.
3. **Text Normalization**: Strips leading/trailing whitespace and normalizes title casing across geographic and category dimensions.
4. **Multi-Format Date Parsing**: Normalizes slash (`/`) and hyphen (`-`) date strings into clean ISO standard `datetime64`.
5. **Range & Type Validation**: Asserts numeric boundaries (`Quantity > 0`, `Sales >= 0`, `0.0 <= Discount <= 1.0`).

---

## 🧬 Feature Engineering
The pipeline enriches the cleaned data with derived operational columns:
- **`Year`**: Calendar year (`2022`–`2025`)
- **`Month`**: Integer month (`1`–`12`)
- **`Month_Name`**: Full month name (`January`, `February`, etc.)
- **`Quarter`**: Fiscal quarter label (`Q1`, `Q2`, `Q3`, `Q4`)
- **`Profit_Margin (%)`**: Vectorized calculation:
  $$\text{Profit Margin} = \left( \frac{\text{Profit}}{\text{Sales}} \right) \times 100$$
- **`Sales_Per_Unit`**: Revenue realized per individual item:
  $$\text{Sales Per Unit} = \frac{\text{Sales}}{\text{Quantity}}$$
- **`Order_Value`**: Row-level transaction order value

---

## 🗄️ Intermediate SQL Analysis
Located in `database/analysis_queries.sql`, the project provides 17 production SQL queries:
- **Aggregations & Metrics**: Executive totals using `SUM()`, `AVG()`, `COUNT(DISTINCT Order_ID)`.
- **Dimensional Breakdowns**: Sales and profit sliced by Month, Region, Category, Sub-Category, and Payment Mode.
- **Window Functions**:
  - `LAG(current_month_sales, 1) OVER (ORDER BY Year, Month)` for Month-over-Month (MoM) growth calculations.
- **Common Table Expressions (CTEs)**:
  - `WITH MonthlySales AS (...)` to compute month-on-month growth.
  - `WITH QuarterlySales AS (...)` to compute Year-over-Year (YoY) quarterly variances.
- **CASE Statements**: Segmenting transactions into discount risk brackets (`0%`, `1-10%`, `11-20%`, `>30%`).

---

## 🖥️ Dashboard Architecture & UI
The application (`app.py`) provides 7 purpose-built analytical tabs:

1. **📊 Executive Overview**: High-level KPIs, 4-year monthly sales line trend with dual hover, regional performance bars, and category contribution donut.
2. **📈 Sales Analysis**: Monthly sales vs profit dual-axis chart, MoM sales growth bar chart with green/red conditional color indicators, and weekly day-of-week sales curve.
3. **💰 Profit Analysis**: Scatter plot of Discount vs. Profit highlighting break-even points, binned discount margin tables, and loss-making SKU tables.
4. **📦 Product & Customer Analysis**: Dynamic ranking selector (Sales, Profit, Quantity), Top 10 vs Bottom 10 SKUs, and interactive Customer Leaderboards.
5. **🌍 Regional Analysis**: Regional sales comparison, State-level drill-down bar chart, and territory profit margin breakdown.
6. **💡 Business Insights**: Dynamic data-driven summaries identifying territory leaders, profit leaders, highest sales months, margin status, and strategic recommendations.
7. **📋 Data Explorer**: Filtered data grid with keyword search and one-click CSV export (`st.download_button`).

---

## 📁 Project Structure
```
sales-performance-analytics/
│
├── app.py                      # Streamlit interactive application
├── requirements.txt            # Project dependencies
├── .env.example                # Sample database configuration
├── .gitignore                  # Git exclusions (.env, caches, venv)
├── README.md                   # Project documentation
├── generate_dataset.py         # Synthetic data generator (7,300+ records)
├── run_tests.py                # Standalone automated test runner
│
├── data/
│   ├── raw_sales_data.csv      # Uncleaned dataset with realistic noise
│   └── sales_data.csv          # Cleaned, feature-engineered dataset
│
├── database/
│   ├── schema.sql              # MySQL DDL table definition & indexes
│   └── analysis_queries.sql    # 17+ Intermediate analytical SQL queries
│
├── src/
│   ├── __init__.py
│   ├── data_cleaning.py        # Loading, profiling, cleaning, and feature engineering
│   ├── data_analysis.py        # Dynamic KPIs, growth rates, rankings, and business insights
│   ├── database.py             # MySQL connector, data loader, query runner, and CSV fallback
│   └── visualizations.py       # Plotly charts with custom enterprise styling
│
├── notebooks/
│   └── sales_analysis.ipynb    # 13-part exploratory data analysis notebook
│
└── tests/
    ├── __init__.py
    └── test_analytics.py       # 8 unit tests for cleaning, calculations, and edge cases
```

---

## ⚙️ Installation & Setup

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/sales-performance-analytics.git
cd sales-performance-analytics
```

### 2. Create and Activate Virtual Environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

---

## 🛢️ MySQL Setup (Optional)
The dashboard operates seamlessly using local cleaned CSV pipelines by default. If you wish to connect MySQL:

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Update `.env` with your MySQL credentials:
   ```ini
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=your_mysql_password
   DB_NAME=sales_analytics
   ```
3. Initialize the database and table schema:
   ```bash
   python -c "from src.database import init_database, load_csv_to_mysql; init_database(); load_csv_to_mysql()"
   ```

---

## ▶️ Running the Application

Launch the Streamlit web dashboard:
```bash
streamlit run app.py
```
Open your browser and navigate to: `http://localhost:8501`

---

## 🧪 Automated Testing
Run the comprehensive test suite to validate pipeline logic, cleaning rules, and mathematical accuracy:
```bash
python run_tests.py
# or using pytest directly:
pytest -v tests/test_analytics.py
```

Expected output:
```
tests/test_analytics.py::test_required_columns_exist PASSED
tests/test_analytics.py::test_duplicate_removal PASSED
tests/test_analytics.py::test_missing_value_handling PASSED
tests/test_analytics.py::test_date_conversion PASSED
tests/test_analytics.py::test_feature_engineering PASSED
tests/test_analytics.py::test_kpi_calculations PASSED
tests/test_analytics.py::test_empty_dataframe_resilience PASSED
tests/test_analytics.py::test_dataset_record_count_threshold PASSED

8 passed in 0.81s
```

---

## 💡 Dynamic Business Insights

Based on 7,300+ sales transactions across 2022–2025:
- **Discount Governance**: Transactions offering discounts **> 20%** exhibit severe margin compression (~**3.5%** net margin vs. **26.8%** for discounts $\le$ 20%). A ceiling on unapproved sales discounts directly preserves bottom-line profit.
- **Territory Concentration**: The **West** and **East** regions drive over **55%** of total enterprise revenue. The **South** territory shows strong AOV but lower transaction volume, indicating an opportunity for regional marketing expansion.
- **Category Profitability**: **Technology** SKUs generate the largest gross revenue, but **Furniture** items (specifically ergonomic desks and chairs) exhibit high logistics overhead, requiring tighter freight management.
- **Seasonality Patterns**: Consistent fourth-quarter (Q4) surges occur in October, November, and December, representing an average **38% uplift** over Q1 baseline volume.

---

## ⚠️ Project Limitations
- **Synthetic Transactions**: The dataset simulates realistic sales patterns and seasonality; however, real-world supply chain disruptions or macroeconomic currency swings are not modeled.
- **Static Pricing Model**: Product base costs and list prices remain fixed throughout the 4-year horizon.
- **Database Fallback Mode**: When MySQL credentials are not configured, analytical calculations default to high-performance vectorized Pandas operations rather than live SQL execution.

---

## 🔮 Future Enhancements
- [ ] Integration of ARIMA / Prophet time-series forecasting for projected Q1 revenue.
- [ ] Automated RFM (Recency, Frequency, Monetary) customer segmentation clustering.
- [ ] Automated scheduled email alerts for margin-negative transactions.
- [ ] Docker containerization for one-command deployment (`docker-compose up`).

---

## 🎓 Learning Outcomes
By building and reviewing this project, you demonstrate competency in:
- Clean code architecture and Python modularization (`src/` structure).
- Real-world data wrangling and validation using Pandas and NumPy.
- Complex analytical SQL querying with Window Functions and CTEs.
- Interactive visualization design and UX ergonomics with Plotly and Streamlit.
- Secure environment configuration and automated testing best practices.
