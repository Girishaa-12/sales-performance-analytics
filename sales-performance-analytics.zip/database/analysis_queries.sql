-- ==========================================================
-- Intermediate SQL Queries for Sales Performance Analytics
-- Database: sales_analytics | Table: sales_data
-- Demonstrates: Aggregations, Grouping, CASE, CTEs, Window Functions
-- ==========================================================

USE sales_analytics;

-- ----------------------------------------------------------
-- 1. Executive KPIs (Total Sales, Profit, Orders, Quantity, AOV, Margin)
-- ----------------------------------------------------------
SELECT 
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    COUNT(DISTINCT Order_ID) AS total_orders,
    SUM(Quantity) AS total_quantity_sold,
    ROUND(SUM(Sales) / COUNT(DISTINCT Order_ID), 2) AS avg_order_value,
    ROUND((SUM(Profit) / SUM(Sales)) * 100, 2) AS overall_profit_margin_pct
FROM sales_data;

-- ----------------------------------------------------------
-- 2. Monthly Sales & Profit Trend
-- ----------------------------------------------------------
SELECT 
    Year,
    Month,
    Month_Name,
    ROUND(SUM(Sales), 2) AS monthly_sales,
    ROUND(SUM(Profit), 2) AS monthly_profit,
    COUNT(DISTINCT Order_ID) AS monthly_orders
FROM sales_data
GROUP BY Year, Month, Month_Name
ORDER BY Year ASC, Month ASC;

-- ----------------------------------------------------------
-- 3. Sales and Profit by Region with Profit Margin
-- ----------------------------------------------------------
SELECT 
    Region,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    COUNT(DISTINCT Order_ID) AS total_orders,
    ROUND((SUM(Profit) / SUM(Sales)) * 100, 2) AS profit_margin_pct,
    ROUND((SUM(Sales) * 100.0 / (SELECT SUM(Sales) FROM sales_data)), 2) AS regional_sales_share_pct
FROM sales_data
GROUP BY Region
ORDER BY total_sales DESC;

-- ----------------------------------------------------------
-- 4. Category Performance & Contribution
-- ----------------------------------------------------------
SELECT 
    Category,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    SUM(Quantity) AS total_quantity,
    ROUND((SUM(Profit) / SUM(Sales)) * 100, 2) AS profit_margin_pct,
    ROUND((SUM(Sales) * 100.0 / (SELECT SUM(Sales) FROM sales_data)), 2) AS category_contribution_pct
FROM sales_data
GROUP BY Category
ORDER BY total_sales DESC;

-- ----------------------------------------------------------
-- 5. Sub-Category Breakdown with Parent Category
-- ----------------------------------------------------------
SELECT 
    Category,
    Sub_Category,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    SUM(Quantity) AS total_quantity,
    ROUND((SUM(Profit) / SUM(Sales)) * 100, 2) AS profit_margin_pct
FROM sales_data
GROUP BY Category, Sub_Category
ORDER BY Category, total_sales DESC;

-- ----------------------------------------------------------
-- 6. Top 10 Products by Sales
-- ----------------------------------------------------------
SELECT 
    Product,
    Category,
    ROUND(SUM(Sales), 2) AS total_sales,
    SUM(Quantity) AS total_quantity,
    ROUND(SUM(Profit), 2) AS total_profit
FROM sales_data
GROUP BY Product, Category
ORDER BY total_sales DESC
LIMIT 10;

-- ----------------------------------------------------------
-- 7. Top 10 Products by Profit
-- ----------------------------------------------------------
SELECT 
    Product,
    Category,
    ROUND(SUM(Profit), 2) AS total_profit,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND((SUM(Profit) / SUM(Sales)) * 100, 2) AS profit_margin_pct
FROM sales_data
GROUP BY Product, Category
ORDER BY total_profit DESC
LIMIT 10;

-- ----------------------------------------------------------
-- 8. Bottom 10 Products by Profit (Loss-Making / Low Margin)
-- ----------------------------------------------------------
SELECT 
    Product,
    Category,
    ROUND(SUM(Profit), 2) AS total_profit,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(AVG(Discount) * 100, 1) AS avg_discount_pct
FROM sales_data
GROUP BY Product, Category
ORDER BY total_profit ASC
LIMIT 10;

-- ----------------------------------------------------------
-- 9. Top 10 Customers by Total Sales
-- ----------------------------------------------------------
SELECT 
    Customer_ID,
    Customer_Name,
    COUNT(DISTINCT Order_ID) AS total_orders,
    SUM(Quantity) AS items_purchased,
    ROUND(SUM(Sales), 2) AS total_spent,
    ROUND(AVG(Sales), 2) AS avg_spent_per_order
FROM sales_data
GROUP BY Customer_ID, Customer_Name
ORDER BY total_spent DESC
LIMIT 10;

-- ----------------------------------------------------------
-- 10. Top 10 Customers by Profit Generated
-- ----------------------------------------------------------
SELECT 
    Customer_ID,
    Customer_Name,
    ROUND(SUM(Profit), 2) AS total_profit_generated,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND((SUM(Profit) / SUM(Sales)) * 100, 2) AS profit_margin_pct
FROM sales_data
GROUP BY Customer_ID, Customer_Name
ORDER BY total_profit_generated DESC
LIMIT 10;

-- ----------------------------------------------------------
-- 11. Customer Order Frequency and AOV Analysis
-- ----------------------------------------------------------
SELECT 
    Customer_ID,
    Customer_Name,
    COUNT(DISTINCT Order_ID) AS order_count,
    ROUND(SUM(Sales), 2) AS customer_lifetime_sales,
    ROUND(SUM(Sales) / COUNT(DISTINCT Order_ID), 2) AS customer_aov
FROM sales_data
GROUP BY Customer_ID, Customer_Name
HAVING order_count >= 3
ORDER BY order_count DESC, customer_lifetime_sales DESC
LIMIT 15;

-- ----------------------------------------------------------
-- 12. Discount Bracket vs Profitability Analysis
-- ----------------------------------------------------------
SELECT 
    CASE 
        WHEN Discount = 0 THEN '0% (No Discount)'
        WHEN Discount > 0 AND Discount <= 0.10 THEN '1% - 10%'
        WHEN Discount > 0.10 AND Discount <= 0.20 THEN '11% - 20%'
        WHEN Discount > 0.20 AND Discount <= 0.30 THEN '21% - 30%'
        ELSE '> 30% (High Discount)'
    END AS discount_bracket,
    COUNT(*) AS total_transactions,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    ROUND((SUM(Profit) / SUM(Sales)) * 100, 2) AS margin_pct
FROM sales_data
GROUP BY discount_bracket
ORDER BY MIN(Discount) ASC;

-- ----------------------------------------------------------
-- 13. Month-over-Month (MoM) Sales Growth using CTE & Window Functions
-- ----------------------------------------------------------
WITH MonthlySales AS (
    SELECT 
        Year,
        Month,
        Month_Name,
        ROUND(SUM(Sales), 2) AS current_month_sales
    FROM sales_data
    GROUP BY Year, Month, Month_Name
),
MonthlyGrowth AS (
    SELECT 
        Year,
        Month,
        Month_Name,
        current_month_sales,
        LAG(current_month_sales, 1) OVER (ORDER BY Year ASC, Month ASC) AS prev_month_sales
    FROM MonthlySales
)
SELECT 
    Year,
    Month,
    Month_Name,
    current_month_sales,
    prev_month_sales,
    ROUND(
        CASE 
            WHEN prev_month_sales IS NULL THEN 0 
            ELSE ((current_month_sales - prev_month_sales) / prev_month_sales) * 100 
        END, 2
    ) AS mom_growth_pct
FROM MonthlyGrowth;

-- ----------------------------------------------------------
-- 14. Year-over-Year (YoY) Sales Growth by Quarter using CTE
-- ----------------------------------------------------------
WITH QuarterlySales AS (
    SELECT 
        Year,
        Quarter,
        ROUND(SUM(Sales), 2) AS quarterly_sales
    FROM sales_data
    GROUP BY Year, Quarter
)
SELECT 
    curr.Year,
    curr.Quarter,
    curr.quarterly_sales,
    prev.quarterly_sales AS prior_year_sales,
    ROUND(
        CASE 
            WHEN prev.quarterly_sales IS NULL THEN NULL 
            ELSE ((curr.quarterly_sales - prev.quarterly_sales) / prev.quarterly_sales) * 100 
        END, 2
    ) AS yoy_growth_pct
FROM QuarterlySales curr
LEFT JOIN QuarterlySales prev 
    ON curr.Quarter = prev.Quarter AND curr.Year = prev.Year + 1
ORDER BY curr.Year ASC, curr.Quarter ASC;

-- ----------------------------------------------------------
-- 15. Payment Mode Performance & Preferences
-- ----------------------------------------------------------
SELECT 
    Payment_Mode,
    COUNT(*) AS transaction_count,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    ROUND(AVG(Sales), 2) AS avg_ticket_size,
    ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM sales_data)), 2) AS transaction_share_pct
FROM sales_data
GROUP BY Payment_Mode
ORDER BY total_sales DESC;

-- ----------------------------------------------------------
-- 16. State-Level Performance within Regions
-- ----------------------------------------------------------
SELECT 
    Region,
    State,
    COUNT(DISTINCT Order_ID) AS orders_count,
    ROUND(SUM(Sales), 2) AS total_sales,
    ROUND(SUM(Profit), 2) AS total_profit,
    ROUND((SUM(Profit) / SUM(Sales)) * 100, 2) AS profit_margin_pct
FROM sales_data
GROUP BY Region, State
ORDER BY Region ASC, total_sales DESC;

-- ----------------------------------------------------------
-- 17. High-Value Orders (Order Value > $2,500)
-- ----------------------------------------------------------
SELECT 
    Order_ID,
    Order_Date,
    Customer_Name,
    Product,
    Quantity,
    Sales,
    Discount,
    Profit
FROM sales_data
WHERE Sales >= 2500
ORDER BY Sales DESC;
