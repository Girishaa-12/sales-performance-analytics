-- ==========================================================
-- Database Schema for Sales Performance Analytics Dashboard
-- Database: sales_analytics
-- Table: sales_data
-- ==========================================================

CREATE DATABASE IF NOT EXISTS sales_analytics;
USE sales_analytics;

DROP TABLE IF EXISTS sales_data;

CREATE TABLE sales_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    Order_ID VARCHAR(50) NOT NULL,
    Order_Date DATE NOT NULL,
    Customer_ID VARCHAR(50) NOT NULL,
    Customer_Name VARCHAR(100) NOT NULL,
    Product VARCHAR(100) NOT NULL,
    Category VARCHAR(50) NOT NULL,
    Sub_Category VARCHAR(50) NOT NULL,
    Region VARCHAR(30) NOT NULL,
    State VARCHAR(50) NOT NULL,
    City VARCHAR(50) NOT NULL,
    Sales DECIMAL(12, 2) NOT NULL,
    Quantity INT NOT NULL,
    Discount DECIMAL(5, 2) NOT NULL,
    Profit DECIMAL(12, 2) NOT NULL,
    Payment_Mode VARCHAR(50) NOT NULL,
    Year INT NOT NULL,
    Month INT NOT NULL,
    Month_Name VARCHAR(20) NOT NULL,
    Quarter VARCHAR(10) NOT NULL,
    Profit_Margin DECIMAL(7, 2) NOT NULL,
    Sales_Per_Unit DECIMAL(12, 2) NOT NULL,
    Order_Value DECIMAL(12, 2) NOT NULL,
    INDEX idx_order_date (Order_Date),
    INDEX idx_region (Region),
    INDEX idx_category (Category),
    INDEX idx_customer_id (Customer_ID),
    INDEX idx_product (Product)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
