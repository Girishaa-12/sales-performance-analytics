"""
Sales Performance Analytics Dashboard
An intermediate-level interactive business intelligence dashboard built with
Streamlit, Plotly, Pandas, and MySQL.
"""

import os
import streamlit as st
import pandas as pd
import numpy as np

# Internal module imports
from src.data_cleaning import load_data, run_pipeline
from src.data_analysis import (
    calculate_kpis,
    get_monthly_sales_trend,
    calculate_sales_growth,
    get_regional_breakdown,
    get_state_breakdown,
    get_product_rankings,
    get_category_metrics,
    get_customer_metrics,
    get_discount_vs_profit_data,
    generate_business_insights
)
from src.visualizations import (
    plot_monthly_sales_trend,
    plot_monthly_sales_vs_profit,
    plot_regional_performance,
    plot_category_breakdown,
    plot_sub_category_sunburst,
    plot_product_rankings,
    plot_discount_vs_profit,
    plot_growth_trend
)
from src.database import test_connection, get_db_connection

# ---------------------------------------------------------
# Page Configuration
# ---------------------------------------------------------
st.set_page_config(
    page_title="Sales Performance Analytics",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------------------------------------------------------
# Custom Professional CSS Styling
# ---------------------------------------------------------
st.markdown("""
<style>
    /* Global Typography and Styling */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Main container padding */
    .block-container {
        padding-top: 1.5rem;
        padding-bottom: 2rem;
        padding-left: 2rem;
        padding-right: 2rem;
    }
    
    /* Metric Cards */
    .metric-card {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 16px 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        transition: transform 0.15s ease, box-shadow 0.15s ease;
    }
    .metric-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .metric-label {
        font-size: 0.85rem;
        font-weight: 600;
        color: #64748B;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 4px;
    }
    .metric-value {
        font-size: 1.75rem;
        font-weight: 700;
        color: #0F172A;
        line-height: 1.2;
    }
    .metric-delta-pos {
        font-size: 0.82rem;
        font-weight: 600;
        color: #10B981;
        margin-top: 6px;
    }
    .metric-delta-neg {
        font-size: 0.82rem;
        font-weight: 600;
        color: #EF4444;
        margin-top: 6px;
    }
    .metric-delta-neutral {
        font-size: 0.82rem;
        font-weight: 500;
        color: #94A3B8;
        margin-top: 6px;
    }
    
    /* Insights Cards */
    .insight-card {
        background: #F8FAFC;
        border-left: 4px solid #2563EB;
        padding: 14px 18px;
        border-radius: 6px;
        margin-bottom: 12px;
    }
    .insight-card-alert {
        background: #FEF2F2;
        border-left: 4px solid #EF4444;
        padding: 14px 18px;
        border-radius: 6px;
        margin-bottom: 12px;
    }
    .insight-card-success {
        background: #F0FDF4;
        border-left: 4px solid #10B981;
        padding: 14px 18px;
        border-radius: 6px;
        margin-bottom: 12px;
    }
    
    /* Status Badge */
    .status-badge-live {
        display: inline-block;
        background: #DCFCE7;
        color: #15803D;
        font-size: 0.75rem;
        font-weight: 600;
        padding: 3px 8px;
        border-radius: 12px;
    }
    .status-badge-csv {
        display: inline-block;
        background: #EFF6FF;
        color: #1D4ED8;
        font-size: 0.75rem;
        font-weight: 600;
        padding: 3px 8px;
        border-radius: 12px;
    }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------
# Data Loading & Caching Pipeline
# ---------------------------------------------------------
@st.cache_data(show_spinner="Loading and preparing sales data...")
def get_clean_dataset() -> pd.DataFrame:
    """
    Loads dataset with automated pipeline fallback.
    """
    clean_path = os.path.join("data", "sales_data.csv")
    raw_path = os.path.join("data", "raw_sales_data.csv")
    
    if os.path.exists(clean_path):
        df = pd.read_csv(clean_path)
    elif os.path.exists(raw_path):
        df, _ = run_pipeline(raw_path, clean_path)
    else:
        # Generate on the fly if not found
        from generate_dataset import generate_synthetic_sales_data
        raw_df = generate_synthetic_sales_data(target_records=7300)
        os.makedirs("data", exist_ok=True)
        raw_df.to_csv(raw_path, index=False)
        df, _ = run_pipeline(raw_path, clean_path)

    # Ensure Order_Date is datetime
    df["Order_Date"] = pd.to_datetime(df["Order_Date"])
    return df


# ---------------------------------------------------------
# Application Header
# ---------------------------------------------------------
col_h1, col_h2 = st.columns([3, 1])
with col_h1:
    st.title("📊 Sales Performance Analytics")
    st.caption("Interactive Enterprise Business Intelligence Dashboard • B.Tech Data Science Portfolio Project")

# Database status check
with col_h2:
    db_status = test_connection()
    if db_status.get("connected"):
        st.markdown("<div style='text-align: right;'><span class='status-badge-live'>🟢 MySQL Connected</span></div>", unsafe_allow_html=True)
    else:
        st.markdown("<div style='text-align: right;'><span class='status-badge-csv'>📁 Cleaned CSV Pipeline (Active)</span></div>", unsafe_allow_html=True)

# ---------------------------------------------------------
# Load Data
# ---------------------------------------------------------
try:
    df_master = get_clean_dataset()
except Exception as err:
    st.error(f"Error loading dataset: {str(err)}")
    st.stop()

# ---------------------------------------------------------
# Sidebar Filter Controls
# ---------------------------------------------------------
st.sidebar.header("🔍 Filter Controls")

# Reset Filters Handler
if "filter_reset" not in st.session_state:
    st.session_state.filter_reset = False

if st.sidebar.button("🔄 Reset Filters", use_container_width=True):
    st.session_state.filter_reset = True
    st.rerun()

# Date bounds
min_date = df_master["Order_Date"].min().date()
max_date = df_master["Order_Date"].max().date()

# 1. Date Range Filter
date_range = st.sidebar.date_input(
    "📅 Date Range",
    value=(min_date, max_date),
    min_value=min_date,
    max_value=max_date
)

# 2. Region Filter
all_regions = sorted(df_master["Region"].dropna().unique().tolist())
selected_regions = st.sidebar.multiselect(
    "🌍 Region",
    options=all_regions,
    default=all_regions
)

# 3. State Filter (cascading based on region)
available_states = df_master[df_master["Region"].isin(selected_regions)]["State"].dropna().unique().tolist() if selected_regions else []
available_states = sorted(available_states)
selected_states = st.sidebar.multiselect(
    "📍 State",
    options=available_states,
    default=available_states
)

# 4. Category Filter
all_categories = sorted(df_master["Category"].dropna().unique().tolist())
selected_categories = st.sidebar.multiselect(
    "🏷️ Category",
    options=all_categories,
    default=all_categories
)

# 5. Product Filter
available_products = df_master[df_master["Category"].isin(selected_categories)]["Product"].dropna().unique().tolist() if selected_categories else []
available_products = sorted(available_products)
selected_products = st.sidebar.multiselect(
    "📦 Product",
    options=available_products,
    default=[]  # Default empty means all products selected
)

# 6. Payment Mode Filter
all_payment_modes = sorted(df_master["Payment_Mode"].dropna().unique().tolist())
selected_payments = st.sidebar.multiselect(
    "💳 Payment Mode",
    options=all_payment_modes,
    default=all_payment_modes
)

# ---------------------------------------------------------
# Apply Filters to DataFrame
# ---------------------------------------------------------
filtered_df = df_master.copy()

# Date filter
if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
    start_date, end_date = date_range
    filtered_df = filtered_df[
        (filtered_df["Order_Date"].dt.date >= start_date) & 
        (filtered_df["Order_Date"].dt.date <= end_date)
    ]

# Region filter
if selected_regions:
    filtered_df = filtered_df[filtered_df["Region"].isin(selected_regions)]
else:
    filtered_df = filtered_df.iloc[0:0]

# State filter
if selected_states:
    filtered_df = filtered_df[filtered_df["State"].isin(selected_states)]
else:
    filtered_df = filtered_df.iloc[0:0]

# Category filter
if selected_categories:
    filtered_df = filtered_df[filtered_df["Category"].isin(selected_categories)]
else:
    filtered_df = filtered_df.iloc[0:0]

# Product filter
if selected_products:
    filtered_df = filtered_df[filtered_df["Product"].isin(selected_products)]

# Payment mode filter
if selected_payments:
    filtered_df = filtered_df[filtered_df["Payment_Mode"].isin(selected_payments)]
else:
    filtered_df = filtered_df.iloc[0:0]

# Previous period dataset for dynamic growth calculation
if isinstance(date_range, (tuple, list)) and len(date_range) == 2 and not filtered_df.empty:
    start_d, end_d = date_range
    period_days = (end_d - start_d).days + 1
    prev_start_d = start_d - pd.Timedelta(days=period_days)
    prev_end_d = start_d - pd.Timedelta(days=1)
    
    prev_df = df_master[
        (df_master["Order_Date"].dt.date >= prev_start_d) &
        (df_master["Order_Date"].dt.date <= prev_end_d)
    ]
    if selected_regions:
        prev_df = prev_df[prev_df["Region"].isin(selected_regions)]
    if selected_categories:
        prev_df = prev_df[prev_df["Category"].isin(selected_categories)]
else:
    prev_df = None

# Calculate KPIs
kpis = calculate_kpis(filtered_df, prev_df=prev_df)

# Check for empty result after filtering
if filtered_df.empty:
    st.warning("⚠️ No records match the selected filter criteria. Please adjust your filters in the sidebar.")
    st.stop()

# ---------------------------------------------------------
# Dynamic KPI Section
# ---------------------------------------------------------
st.markdown("### 📌 Key Performance Indicators")

def format_delta(val, suffix="%"):
    if val is None:
        return "<div class='metric-delta-neutral'>No prior baseline</div>"
    if val > 0:
        return f"<div class='metric-delta-pos'>▲ +{val:.1f}{suffix} vs prior period</div>"
    elif val < 0:
        return f"<div class='metric-delta-neg'>▼ {val:.1f}{suffix} vs prior period</div>"
    return f"<div class='metric-delta-neutral'>0.0{suffix} vs prior period</div>"

kpi_c1, kpi_c2, kpi_c3, kpi_c4, kpi_c5, kpi_c6 = st.columns(6)

with kpi_c1:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">💰 Total Sales</div>
        <div class="metric-value">${kpis['total_sales']:,.0f}</div>
        {format_delta(kpis['sales_growth_pct'])}
    </div>
    """, unsafe_allow_html=True)

with kpi_c2:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">📈 Total Profit</div>
        <div class="metric-value">${kpis['total_profit']:,.0f}</div>
        {format_delta(kpis['profit_growth_pct'])}
    </div>
    """, unsafe_allow_html=True)

with kpi_c3:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">🧾 Total Orders</div>
        <div class="metric-value">{kpis['total_orders']:,}</div>
        {format_delta(kpis['orders_growth_pct'])}
    </div>
    """, unsafe_allow_html=True)

with kpi_c4:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">📦 Quantity Sold</div>
        <div class="metric-value">{kpis['quantity_sold']:,}</div>
        <div class="metric-delta-neutral">Units fulfilled</div>
    </div>
    """, unsafe_allow_html=True)

with kpi_c5:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">💵 Avg Order Value</div>
        <div class="metric-value">${kpis['avg_order_value']:,.2f}</div>
        <div class="metric-delta-neutral">Revenue per order</div>
    </div>
    """, unsafe_allow_html=True)

with kpi_c6:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">📊 Profit Margin</div>
        <div class="metric-value">{kpis['profit_margin_pct']:.1f}%</div>
        <div class="metric-delta-neutral">Net margin realized</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ---------------------------------------------------------
# 7 Dashboard Tabs
# ---------------------------------------------------------
tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
    "📊 Executive Overview",
    "📈 Sales Analysis",
    "💰 Profit Analysis",
    "📦 Product & Customer",
    "🌍 Regional Analysis",
    "💡 Business Insights",
    "📋 Data Explorer"
])

# ---------------------------------------------------------
# Tab 1: Executive Overview
# ---------------------------------------------------------
with tab1:
    st.subheader("Executive Performance Overview")
    
    col_t1, col_t2 = st.columns([3, 2])
    with col_t1:
        trend_data = get_monthly_sales_trend(filtered_df)
        fig_trend = plot_monthly_sales_trend(trend_data)
        st.plotly_chart(fig_trend, use_container_width=True, key="tab1_monthly_sales_trend")
        
    with col_t2:
        cat_data, _ = get_category_metrics(filtered_df)
        fig_cat = plot_category_breakdown(cat_data)
        st.plotly_chart(fig_cat, use_container_width=True, key="tab1_category_breakdown")
        
    col_t3, col_t4 = st.columns([3, 2])
    with col_t3:
        reg_data = get_regional_breakdown(filtered_df)
        fig_reg = plot_regional_performance(reg_data)
        st.plotly_chart(fig_reg, use_container_width=True, key="tab1_regional_performance")
        
    with col_t4:
        st.markdown("#### 🏆 Quick Category Summary")
        cat_display = cat_data[["Category", "Sales", "Profit", "Margin_Pct", "Contribution_Pct"]].copy()
        cat_display["Sales"] = cat_display["Sales"].apply(lambda x: f"${x:,.2f}")
        cat_display["Profit"] = cat_display["Profit"].apply(lambda x: f"${x:,.2f}")
        cat_display["Margin_Pct"] = cat_display["Margin_Pct"].apply(lambda x: f"{x:.1f}%")
        cat_display["Contribution_Pct"] = cat_display["Contribution_Pct"].apply(lambda x: f"{x:.1f}%")
        st.dataframe(cat_display, use_container_width=True, hide_index=True)

# ---------------------------------------------------------
# Tab 2: Sales Analysis
# ---------------------------------------------------------
with tab2:
    st.subheader("Detailed Sales Trend & Growth Dynamics")
    
    trend_data = get_monthly_sales_trend(filtered_df)
    growth_data = calculate_sales_growth(filtered_df)
    
    col_s1, col_s2 = st.columns(2)
    with col_s1:
        fig_s_vs_p = plot_monthly_sales_vs_profit(trend_data)
        st.plotly_chart(fig_s_vs_p, use_container_width=True, key="tab2_sales_vs_profit")
    with col_s2:
        fig_growth = plot_growth_trend(growth_data)
        st.plotly_chart(fig_growth, use_container_width=True, key="tab2_growth_trend")
        
    st.markdown("#### 💳 Sales by Payment Mode & Day of Week")
    col_s3, col_s4 = st.columns(2)
    with col_s3:
        pay_df = filtered_df.groupby("Payment_Mode", as_index=False).agg(
            Sales=("Sales", "sum"),
            Orders=("Order_ID", "nunique")
        ).sort_values(by="Sales", ascending=False)
        import plotly.express as px
        fig_pay = px.bar(
            pay_df,
            x="Payment_Mode",
            y="Sales",
            color="Payment_Mode",
            text=pay_df["Sales"].apply(lambda x: f"${x:,.0f}"),
            title="Revenue by Payment Channel",
            color_discrete_sequence=["#1E40AF", "#3B82F6", "#10B981", "#F59E0B"]
        )
        fig_pay.update_layout(plot_bgcolor="rgba(248, 250, 252, 0.5)", showlegend=False)
        fig_pay.update_yaxes(tickprefix="$", tickformat=",.0f")
        st.plotly_chart(fig_pay, use_container_width=True, key="tab2_payment_channel")
        
    with col_s4:
        df_dow = filtered_df.copy()
        df_dow["Day_of_Week"] = df_dow["Order_Date"].dt.day_name()
        days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        dow_agg = df_dow.groupby("Day_of_Week", as_index=False)["Sales"].sum()
        dow_agg["Day_of_Week"] = pd.Categorical(dow_agg["Day_of_Week"], categories=days_order, ordered=True)
        dow_agg = dow_agg.sort_values("Day_of_Week")
        
        fig_dow = px.line(
            dow_agg,
            x="Day_of_Week",
            y="Sales",
            markers=True,
            title="Weekly Sales Distribution",
            line_shape="spline"
        )
        fig_dow.update_traces(line_color="#2563EB", marker_size=8)
        fig_dow.update_layout(plot_bgcolor="rgba(248, 250, 252, 0.5)")
        fig_dow.update_yaxes(tickprefix="$", tickformat=",.0f")
        st.plotly_chart(fig_dow, use_container_width=True, key="tab2_day_of_week")

# ---------------------------------------------------------
# Tab 3: Profit Analysis
# ---------------------------------------------------------
with tab3:
    st.subheader("Profitability & Discount Elasticity")
    
    st.markdown("""
    This section analyzes gross profit realization and evaluates **discount margin erosion**.
    When discounts exceed 20%, procurement and shipping overheads frequently result in negative transaction profit.
    """)
    
    fig_scatter = plot_discount_vs_profit(filtered_df)
    st.plotly_chart(fig_scatter, use_container_width=True, key="tab3_discount_vs_profit")
    
    col_p1, col_p2 = st.columns(2)
    with col_p1:
        st.markdown("#### 📉 Profitability by Discount Bracket")
        disc_binned = get_discount_vs_profit_data(filtered_df)
        if not disc_binned.empty:
            disc_display = disc_binned[["Discount_Bracket", "Transactions", "Sales", "Profit", "Margin_Pct"]].copy()
            disc_display["Sales"] = disc_display["Sales"].apply(lambda x: f"${x:,.2f}")
            disc_display["Profit"] = disc_display["Profit"].apply(lambda x: f"${x:,.2f}")
            disc_display["Margin_Pct"] = disc_display["Margin_Pct"].apply(lambda x: f"{x:.1f}%")
            st.dataframe(disc_display, use_container_width=True, hide_index=True)
            
    with col_p2:
        st.markdown("#### ⚠️ Loss-Making Transactions / Products")
        loss_df = filtered_df[filtered_df["Profit"] < 0].groupby("Product", as_index=False).agg(
            Loss_Transactions=("Order_ID", "count"),
            Total_Loss=("Profit", "sum"),
            Avg_Discount=("Discount", "mean")
        ).sort_values(by="Total_Loss", ascending=True).head(5)
        
        if not loss_df.empty:
            loss_df["Total_Loss"] = loss_df["Total_Loss"].apply(lambda x: f"${x:,.2f}")
            loss_df["Avg_Discount"] = loss_df["Avg_Discount"].apply(lambda x: f"{x*100:.1f}%")
            st.dataframe(loss_df, use_container_width=True, hide_index=True)
        else:
            st.success("No loss-making products found under current filter selection!")

# ---------------------------------------------------------
# Tab 4: Product & Customer Analysis
# ---------------------------------------------------------
with tab4:
    st.subheader("Product & Customer Intelligence")
    
    st.markdown("#### 📦 Product Ranking Analytics")
    col_metric, col_topn = st.columns([2, 1])
    with col_metric:
        chosen_metric = st.selectbox("Select Ranking Metric:", ["Sales", "Profit", "Quantity"])
    with col_topn:
        top_n = st.slider("Select Number of Products:", min_value=5, max_value=20, value=10)
        
    col_prod1, col_prod2 = st.columns(2)
    with col_prod1:
        top_prods = get_product_rankings(filtered_df, metric=chosen_metric, top_n=top_n, ascending=False)
        fig_top_p = plot_product_rankings(top_prods, metric=chosen_metric, title=f"Top {top_n} Products by {chosen_metric}")
        st.plotly_chart(fig_top_p, use_container_width=True, key="tab4_top_products")
        
    with col_prod2:
        bottom_prods = get_product_rankings(filtered_df, metric=chosen_metric, top_n=top_n, ascending=True)
        fig_bot_p = plot_product_rankings(bottom_prods, metric=chosen_metric, title=f"Bottom {top_n} Products by {chosen_metric}")
        st.plotly_chart(fig_bot_p, use_container_width=True, key="tab4_bottom_products")

    st.markdown("---")
    st.markdown("#### 👥 Customer Leaderboard")
    cust_metrics = get_customer_metrics(filtered_df, top_n=10)
    
    cust_tab1, cust_tab2, cust_tab3 = st.tabs(["Top Customers by Sales", "Top Customers by Profit", "Most Frequent Shoppers"])
    with cust_tab1:
        st.dataframe(cust_metrics["by_sales"], use_container_width=True, hide_index=True)
    with cust_tab2:
        st.dataframe(cust_metrics["by_profit"], use_container_width=True, hide_index=True)
    with cust_tab3:
        st.dataframe(cust_metrics["by_orders"], use_container_width=True, hide_index=True)

# ---------------------------------------------------------
# Tab 5: Regional Analysis
# ---------------------------------------------------------
with tab5:
    st.subheader("Geographic & State-Level Performance")
    
    col_r1, col_r2 = st.columns([1, 1])
    with col_r1:
        reg_df = get_regional_breakdown(filtered_df)
        fig_reg_bar = plot_regional_performance(reg_df)
        st.plotly_chart(fig_reg_bar, use_container_width=True, key="tab5_regional_performance")
        
    with col_r2:
        st.markdown("#### 🗺️ Regional Contribution Breakdown")
        reg_table = reg_df.copy()
        reg_table["Sales"] = reg_table["Sales"].apply(lambda x: f"${x:,.2f}")
        reg_table["Profit"] = reg_table["Profit"].apply(lambda x: f"${x:,.2f}")
        reg_table["Margin_Pct"] = reg_table["Margin_Pct"].apply(lambda x: f"{x:.1f}%")
        reg_table["Contribution_Pct"] = reg_table["Contribution_Pct"].apply(lambda x: f"{x:.1f}%")
        st.dataframe(reg_table, use_container_width=True, hide_index=True)

    st.markdown("#### 📍 State Performance Drill-Down")
    state_df = get_state_breakdown(filtered_df)
    import plotly.express as px
    fig_state = px.bar(
        state_df.head(15),
        x="Sales",
        y="State",
        color="Region",
        orientation="h",
        text=state_df.head(15)["Sales"].apply(lambda x: f"${x:,.0f}"),
        title="Top 15 States by Sales Volume"
    )
    fig_state.update_layout(yaxis=dict(autorange="reversed"), plot_bgcolor="rgba(248, 250, 252, 0.5)")
    fig_state.update_xaxes(tickprefix="$", tickformat=",.0f")
    st.plotly_chart(fig_state, use_container_width=True, key="tab5_state_drilldown")

# ---------------------------------------------------------
# Tab 6: Business Insights
# ---------------------------------------------------------
with tab6:
    st.subheader("💡 Dynamic Automated Business Insights")
    st.caption("Generated directly from current filtered parameters — no hardcoded metrics.")
    
    insights = generate_business_insights(filtered_df)
    
    if insights.get("status") == "success":
        col_in1, col_in2 = st.columns(2)
        with col_in1:
            st.markdown(f"""
            <div class="insight-card">
                <b>🌍 Regional Champion</b><br>
                The top-performing territory is <b>{insights['best_region']}</b>, generating 
                <b>${insights['best_region_sales']:,.2f}</b> (<b>{insights['best_region_share']}%</b> of total filtered sales).<br>
                Underperforming territory: <b>{insights['weakest_region']}</b> (${insights['weakest_region_sales']:,.2f}, {insights['weakest_region_share']}% share).
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown(f"""
            <div class="insight-card">
                <b>🏷️ Category Contribution</b><br>
                Leading revenue driver: <b>{insights['best_category']}</b> ({insights['best_category_share']}% share).<br>
                Most profitable category: <b>{insights['most_profitable_category']}</b> with an average profit margin of <b>{insights['most_profitable_category_margin']}%</b>.
            </div>
            """, unsafe_allow_html=True)
            
        with col_in2:
            st.markdown(f"""
            <div class="insight-card">
                <b>📦 Product Highlights</b><br>
                Star Performer: <b>{insights['top_product']}</b> with <b>${insights['top_product_sales']:,.2f}</b> in revenue.<br>
                Lowest Profit Line: <b>{insights['lowest_profit_product']}</b> (${insights['lowest_profit_value']:,.2f} profit).
            </div>
            """, unsafe_allow_html=True)
            
            st.markdown(f"""
            <div class="insight-card">
                <b>📅 Peak Performance Period</b><br>
                Highest Sales Month: <b>{insights['highest_sales_month']}</b> (${insights['highest_sales_month_val']:,.2f}).<br>
                Highest Profit Month: <b>{insights['highest_profit_month']}</b> (${insights['highest_profit_month_val']:,.2f}).
            </div>
            """, unsafe_allow_html=True)
            
        st.markdown("#### 🎯 Strategic Action Plan & Recommendations")
        for rec in insights["recommendations"]:
            st.markdown(f"- {rec}")
            
        st.markdown("#### 🩺 Margin Health Assessment")
        health_color = "#10B981" if insights["margin_health"] in ["Healthy", "Exceptional"] else "#EF4444"
        st.markdown(f"""
        <div style="padding: 12px 16px; border-radius: 8px; border: 1px solid #E2E8F0; background: #FFFFFF;">
            Overall Portfolio Margin: <b>{insights['overall_profit_margin_pct']}%</b> 
            — Status: <span style="color: {health_color}; font-weight: 700;">{insights['margin_health']}</span><br>
            Average Discount: <b>{insights['avg_discount_pct']}%</b>. Discretionary discounts above 20% reduce average margin to <b>{insights['high_discount_margin_pct']}%</b>.
        </div>
        """, unsafe_allow_html=True)

# ---------------------------------------------------------
# Tab 7: Data Explorer
# ---------------------------------------------------------
with tab7:
    st.subheader("📋 Interactive Data Explorer")
    st.caption(f"Displaying {len(filtered_df):,} matching transaction records")
    
    col_exp1, col_exp2 = st.columns([3, 1])
    with col_exp1:
        search_query = st.text_input("🔎 Search by Customer Name, Order ID, or Product:", "")
    with col_exp2:
        # Download filtered CSV
        csv_bytes = filtered_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="⬇️ Download Filtered Data (CSV)",
            data=csv_bytes,
            file_name="filtered_sales_data.csv",
            mime="text/csv",
            use_container_width=True
        )
        
    display_df = filtered_df.copy()
    if search_query:
        mask = (
            display_df["Customer_Name"].str.contains(search_query, case=False, na=False) |
            display_df["Order_ID"].str.contains(search_query, case=False, na=False) |
            display_df["Product"].str.contains(search_query, case=False, na=False)
        )
        display_df = display_df[mask]
        
    st.dataframe(
        display_df,
        use_container_width=True,
        hide_index=True,
        height=500
    )
