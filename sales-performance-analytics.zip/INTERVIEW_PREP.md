# 🎓 B.Tech Data Science Interview Preparation Guide
## Sales Performance Analytics Dashboard

This guide provides clear, confident, and professional answers tailored for a **B.Tech Data Science fresher** to ace interview questions about this project.

---

### 1. Explain your project.
> **Answer:**  
> "I built an interactive **Sales Performance Analytics Dashboard** using Python, Pandas, MySQL, Plotly, and Streamlit. The dashboard analyzes over 7,300 retail sales transactions spanning multiple years (2022 to 2025). It provides executive leadership with real-time visibility into revenue and profit trends, regional performance, customer buying patterns, and product profitability. It also features dynamic period-over-period KPI comparisons, discount-to-profit margin erosion analysis, and automated data-driven business insights."

---

### 2. Why did you choose this project?
> **Answer:**  
> "I chose this project because in business, companies often focus only on top-line revenue while ignoring whether high discounts are eating away at their bottom-line profits. I wanted to build a realistic, intermediate-level project that mirrors how data analysts solve real commercial problems: taking messy transactional data, building a clean data pipeline, storing and querying it with SQL, and presenting interactive business intelligence through a web dashboard."

---

### 3. What was your dataset?
> **Answer:**  
> "The dataset contains 7,300+ sales records across four operating years (2022–2025). It includes 15 primary attributes: `Order_ID`, `Order_Date`, `Customer_ID`, `Customer_Name`, `Product`, `Category`, `Sub_Category`, `Region`, `State`, `City`, `Sales`, `Quantity`, `Discount`, `Profit`, and `Payment_Mode`. It spans 4 geographical regions, 25+ states, 3 major categories (Technology, Furniture, Office Supplies), 40 distinct products, and 500+ repeat customers. The dataset is synthetic, designed with realistic seasonality (like Q4 holiday spikes) and real-world data flaws like missing values and duplicate rows to test the cleaning pipeline."

---

### 4. How did you clean the data?
> **Answer:**  
> "I built a reusable, modular Python pipeline in `src/data_cleaning.py`. The pipeline:
> 1. **Removed Duplicate Records**: Detected and eliminated duplicate transaction rows using `drop_duplicates()`.
> 2. **Handled Missing Values**: Checked for nulls across all columns. Imputed non-critical categorical columns (like payment mode) using the statistical mode, while verifying critical keys like Order ID and Sales.
> 3. **Standardized Text**: Stripped whitespace and normalized string casing for regions, cities, and categories.
> 4. **Handled Multi-format Dates**: Converted both slash (`YYYY/MM/DD`) and hyphenated (`YYYY-MM-DD`) date strings into standardized `datetime64` format.
> 5. **Validated Numeric Ranges**: Verified that quantities were strictly positive and discounts fell within the valid 0% to 100% range."

---

### 5. What role did Pandas play?
> **Answer:**  
> "Pandas was the core data manipulation engine. I used it to:
> - Profile raw datasets (`isnull()`, `duplicated()`, `memory_usage()`).
> - Vectorize data transformations and handle datetime features.
> - Aggregate metrics across multiple dimensions using `groupby()` and `agg()`.
> - Calculate rolling and percentage changes (`pct_change()`).
> - Filter datasets reactively based on user inputs from the Streamlit sidebar."

---

### 6. Why did you use MySQL?
> **Answer:**  
> "In enterprise data environments, transactional data is stored in relational databases, not isolated CSV files. I used MySQL to design a normalized relational schema with primary keys and indexes on `Order_Date`, `Region`, and `Category`. I wrote 17 intermediate SQL analytical queries utilizing aggregations (`SUM`, `COUNT`, `AVG`), Common Table Expressions (CTEs), and Window Functions (`LAG() OVER()`) to demonstrate how data warehousing queries work behind the scenes."

---

### 7. Why Streamlit?
> **Answer:**  
> "Streamlit allows data analysts to build professional, interactive data web applications purely in Python without needing front-end web development frameworks like React or Angular. It provides reactive session state, fast data caching (`@st.cache_data`), built-in filters (date pickers, dropdowns), and easy layout organization using tabs and columns."

---

### 8. Why Plotly?
> **Answer:**  
> "Unlike static plotting libraries like Matplotlib or Seaborn, Plotly generates interactive, web-native JavaScript charts. Users can hover over individual data points to see formatted monetary values and percentages, zoom into specific date windows, toggle legend items on and off, and download high-resolution chart snapshots."

---

### 9. What KPIs did you calculate?
> **Answer:**  
> "I calculated 6 core executive KPIs:
> 1. **Total Sales**: Total monetary revenue generated ($).
> 2. **Total Profit**: Net earnings realized after cost and overhead ($).
> 3. **Total Orders**: Count of distinct transactions fulfilled.
> 4. **Quantity Sold**: Total units delivered.
> 5. **Average Order Value (AOV)**: $\frac{\text{Total Sales}}{\text{Total Orders}}$.
> 6. **Profit Margin %**: $\left(\frac{\text{Total Profit}}{\text{Total Sales}}\right) \times 100$.
> 
> I also dynamically calculated period-over-period percentage growth (`Sales Growth %` and `Profit Growth %`) by comparing the filtered timeframe with the preceding calendar period."

---

### 10. How did you calculate profit margin?
> **Answer:**  
> "Profit margin was calculated as the ratio of net profit to net sales expressed as a percentage:
> $$\text{Profit Margin} = \left( \frac{\text{Profit}}{\text{Sales}} \right) \times 100$$
> In Python, I implemented this safely using `np.where(Sales > 0, (Profit / Sales) * 100, 0.0)` to prevent runtime division-by-zero errors in case of edge cases or zero-sales records."

---

### 11. How did you calculate sales growth?
> **Answer:**  
> "I implemented sales growth at two levels:
> 1. **Period-over-Period (Dashboard KPIs)**:
>    $$\text{Sales Growth \%} = \left( \frac{\text{Current Period Sales} - \text{Previous Period Sales}}{\text{Previous Period Sales}} \right) \times 100$$
> 2. **Month-over-Month (MoM) in SQL and Pandas**:  
>    In SQL, I used the window function `LAG(current_month_sales, 1) OVER (ORDER BY Year, Month)`. In Pandas, I used `.pct_change() * 100` on the chronologically sorted monthly aggregate table."

---

### 12. How did you identify top-performing products?
> **Answer:**  
> "I grouped the dataset by `Product`, `Category`, and `Sub_Category`, and aggregated the sum of `Sales`, `Profit`, and `Quantity`. In the dashboard, I added a dynamic metric selector allowing the user to rank products by Sales, Profit, or Volume. This revealed important business nuances—for example, a product can be #1 in total sales volume but low in profitability due to high discount rates."

---

### 13. How did you generate business insights?
> **Answer:**  
> "Instead of writing static or hardcoded text, I developed an algorithmic insight engine in `src/data_analysis.py`. The function evaluates the currently active filtered DataFrame, identifies the maximum and minimum sales regions, extracts the most and least profitable categories, flags loss-making SKUs, measures average discount rates, and compares the margin of transactions with >20% discount against low-discount transactions. It then returns dynamic, contextual sentences and tactical recommendations."

---

### 14. What challenges did you face?
> **Answer:**  
> "I faced three main challenges:
> 1. **Handling Inconsistent Date Formats**: Raw data had mixed date separators (`/` and `-`). I sanitized the date strings before running `pd.to_datetime` to prevent dropping valid entries.
> 2. **Dynamic Period Comparison**: Accurately calculating previous period baseline dates dynamically based on whatever arbitrary date range the user picked in the sidebar.
> 3. **Division-by-Zero & Empty Filter Handling**: Preventing Streamlit crashes when users selected filter combinations that produced zero matching rows. I added defensive guards and friendly user warning messages."

---

### 15. What would you improve in the future?
> **Answer:**  
> "If given more time, I would:
> 1. Add predictive time-series forecasting using ARIMA or Prophet to forecast Q1 sales and demand.
> 2. Implement RFM (Recency, Frequency, Monetary) customer segmentation using K-Means clustering to identify customer lifetime value tiers.
> 3. Set up automated email or Slack webhook notifications when any transaction falls below a 5% profit margin."
