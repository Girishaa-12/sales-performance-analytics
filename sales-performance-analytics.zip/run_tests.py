"""
Test Runner Script
Project: Sales Performance Analytics Dashboard
Runs automated unit tests and reports pipeline validation status.
"""

import sys
import pytest

if __name__ == "__main__":
    print("=" * 65)
    print("  RUNNING AUTOMATED UNIT TESTS FOR SALES PERFORMANCE ANALYTICS")
    print("=" * 65)
    
    args = ["-v", "tests/test_analytics.py"]
    exit_code = pytest.main(args)
    
    if exit_code == 0:
        print("\n" + "=" * 65)
        print("  ALL TESTS PASSED SUCCESSFULLY! (Pipeline & KPI Math Validated)")
        print("=" * 65)
    else:
        print("\n" + "=" * 65)
        print("  SOME TESTS FAILED! Check traceback above.")
        print("=" * 65)
        
    sys.exit(exit_code)
