"""
Automated Test Suite for Sales Performance Analytics Dashboard
Tests data loading, schema integrity, data cleaning, feature engineering,
KPI calculations, period-over-period growth, and edge case resilience.
"""

import os
import pytest
import pandas as pd
import numpy as np

from src.data_cleaning import (
    load_data,
    profile_data,
    handle_missing_values,
    remove_duplicates,
    clean_text_columns,
    validate_and_convert_dates,
    validate_numeric_columns,
    engineer_features,
    run_pipeline,
    REQUIRED_COLUMNS
)
from src.data_analysis import (
    calculate_kpis,
    get_monthly_sales_trend,
    calculate_sales_growth,
    get_regional_breakdown,
    get_product_rankings,
    get_category_metrics,
    get_customer_metrics,
    generate_business_insights
)


@pytest.fixture
def sample_raw_data():
    """Provides a synthetic raw DataFrame with known dirty inputs."""
    data = {
        "Order_ID": ["ORD-2024-001", "ORD-2024-001", "ORD-2024-002", "ORD-2024-003", "ORD-2024-004"],
        "Order_Date": ["2024-01-15", "2024-01-15", "2024/02/20", "2024-03-10", "2024-04-05"],
        "Customer_ID": ["CUST-101", "CUST-101", "CUST-102", "CUST-103", "CUST-104"],
        "Customer_Name": ["John Doe", "John Doe", "Jane Smith", "Alex Brown", "Emily Davis"],
        "Product": ["Dell XPS 15", "Dell XPS 15", "iPhone 15", "Desk Chair", "Paper Ream"],
        "Category": ["Technology", "Technology", "Technology", "Furniture", "Office Supplies"],
        "Sub_Category": ["Laptops", "Laptops", "Phones", "Chairs", "Paper"],
        "Region": ["North", "North", "South ", "East", "West"],
        "State": ["Illinois", "Illinois", "Texas", "New York", "California"],
        "City": ["Chicago", "Chicago", "Austin ", "New York City", "Los Angeles"],
        "Sales": [1500.0, 1500.0, 800.0, 250.0, 50.0],
        "Quantity": [1, 1, 2, 1, 5],
        "Discount": [0.10, 0.10, 0.0, 0.25, 0.0],
        "Profit": [350.0, 350.0, 200.0, -25.0, 15.0],
        "Payment_Mode": ["Credit Card", "Credit Card", None, "UPI / Net Banking", "Cash on Delivery"]
    }
    return pd.DataFrame(data)


def test_required_columns_exist():
    """Verify that all 15 required raw columns are specified and validated."""
    assert len(REQUIRED_COLUMNS) == 15
    for col in ["Order_ID", "Sales", "Profit", "Quantity", "Discount", "Payment_Mode"]:
        assert col in REQUIRED_COLUMNS


def test_duplicate_removal(sample_raw_data):
    """Test deduplication logic."""
    assert sample_raw_data.duplicated().sum() == 1
    cleaned = remove_duplicates(sample_raw_data)
    assert len(cleaned) == 4
    assert cleaned.duplicated().sum() == 0


def test_missing_value_handling(sample_raw_data):
    """Test imputation of missing categorical and numeric values."""
    cleaned = handle_missing_values(sample_raw_data)
    assert cleaned["Payment_Mode"].isnull().sum() == 0
    # Mode should be imputed for Payment_Mode
    assert cleaned.loc[2, "Payment_Mode"] == "Credit Card"


def test_date_conversion(sample_raw_data):
    """Test standardizing both slash and hyphen date formats."""
    cleaned = validate_and_convert_dates(sample_raw_data)
    assert pd.api.types.is_datetime64_any_dtype(cleaned["Order_Date"])
    assert cleaned["Order_Date"].dt.year.tolist() == [2024, 2024, 2024, 2024, 2024]


def test_feature_engineering(sample_raw_data):
    """Test creation of derived analytical columns."""
    cleaned = validate_and_convert_dates(sample_raw_data)
    eng = engineer_features(cleaned)
    
    expected_derived = ["Year", "Month", "Month_Name", "Quarter", "Profit_Margin", "Sales_Per_Unit", "Order_Value"]
    for col in expected_derived:
        assert col in eng.columns
        
    # Check Profit_Margin = (Profit / Sales) * 100
    # First row: Sales=1500, Profit=350 -> 23.33%
    assert eng.loc[0, "Profit_Margin"] == round((350.0 / 1500.0) * 100, 2)
    # Fourth row: Sales=250, Profit=-25 -> -10.0%
    assert eng.loc[3, "Profit_Margin"] == -10.0
    # Fifth row: Sales=50, Quantity=5 -> Sales_Per_Unit = 10.0
    assert eng.loc[4, "Sales_Per_Unit"] == 10.0


def test_kpi_calculations():
    """Test mathematical accuracy of KPI calculations and growth comparison."""
    df_curr = pd.DataFrame({
        "Order_ID": ["ORD-1", "ORD-2"],
        "Sales": [1000.0, 2000.0],
        "Profit": [200.0, 400.0],
        "Quantity": [2, 4]
    })
    
    df_prev = pd.DataFrame({
        "Order_ID": ["ORD-0"],
        "Sales": [2000.0],
        "Profit": [300.0],
        "Quantity": [2]
    })
    
    kpis = calculate_kpis(df_curr, prev_df=df_prev)
    assert kpis["total_sales"] == 3000.0
    assert kpis["total_profit"] == 600.0
    assert kpis["total_orders"] == 2
    assert kpis["quantity_sold"] == 6
    assert kpis["avg_order_value"] == 1500.0
    assert kpis["profit_margin_pct"] == 20.0
    # Sales Growth = ((3000 - 2000) / 2000) * 100 = +50.0%
    assert kpis["sales_growth_pct"] == 50.0
    # Profit Growth = ((600 - 300) / 300) * 100 = +100.0%
    assert kpis["profit_growth_pct"] == 100.0


def test_empty_dataframe_resilience():
    """Ensure zero division or crash does not occur on empty filtered DataFrame."""
    empty_df = pd.DataFrame(columns=["Order_ID", "Order_Date", "Sales", "Profit", "Quantity", "Discount", "Region", "Category", "Product"])
    kpis = calculate_kpis(empty_df)
    assert kpis["total_sales"] == 0.0
    assert kpis["total_orders"] == 0
    assert kpis["avg_order_value"] == 0.0
    assert kpis["profit_margin_pct"] == 0.0
    
    trend = get_monthly_sales_trend(empty_df)
    assert trend.empty
    
    insights = generate_business_insights(empty_df)
    assert insights["status"] == "empty"


def test_dataset_record_count_threshold():
    """Ensure generated dataset meets the project requirement of >= 5,000 records."""
    csv_path = os.path.join("data", "sales_data.csv")
    if os.path.exists(csv_path):
        df = pd.read_csv(csv_path)
        assert len(df) >= 5000, f"Expected at least 5,000 records, got {len(df)}"
