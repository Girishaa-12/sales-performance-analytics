# Package initialization for tests
