"""
Synthetic Sales Dataset Generator
Project: Sales Performance Analytics Dashboard
Generates a realistic multi-year sales dataset with 7,000+ records,
featuring realistic pricing, discount elasticity, seasonality, and
real-world data imperfections for data cleaning pipelines.
"""

import os
import random
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Set random seed for reproducibility
np.random.seed(42)
random.seed(42)

# Catalog definitions
PRODUCT_CATALOG = [
    # Technology - Laptops
    {"Product": "Dell XPS 15", "Category": "Technology", "Sub_Category": "Laptops", "Price": 1450.00, "Cost": 1050.00},
    {"Product": "MacBook Pro 14", "Category": "Technology", "Sub_Category": "Laptops", "Price": 1899.00, "Cost": 1380.00},
    {"Product": "Lenovo ThinkPad X1", "Category": "Technology", "Sub_Category": "Laptops", "Price": 1150.00, "Cost": 820.00},
    {"Product": "HP Spectre x360", "Category": "Technology", "Sub_Category": "Laptops", "Price": 1299.00, "Cost": 940.00},
    # Technology - Phones
    {"Product": "iPhone 15 Pro", "Category": "Technology", "Sub_Category": "Phones", "Price": 999.00, "Cost": 710.00},
    {"Product": "Samsung Galaxy S24", "Category": "Technology", "Sub_Category": "Phones", "Price": 849.00, "Cost": 600.00},
    {"Product": "Google Pixel 8", "Category": "Technology", "Sub_Category": "Phones", "Price": 699.00, "Cost": 490.00},
    {"Product": "OnePlus 12", "Category": "Technology", "Sub_Category": "Phones", "Price": 799.00, "Cost": 560.00},
    # Technology - Accessories
    {"Product": "Logitech MX Master 3S", "Category": "Technology", "Sub_Category": "Accessories", "Price": 99.99, "Cost": 48.00},
    {"Product": "Keychron K2 Mechanical Keyboard", "Category": "Technology", "Sub_Category": "Accessories", "Price": 89.00, "Cost": 42.00},
    {"Product": "Sony WH-1000XM5 Headphones", "Category": "Technology", "Sub_Category": "Accessories", "Price": 349.99, "Cost": 220.00},
    {"Product": "Anker 7-in-1 USB-C Hub", "Category": "Technology", "Sub_Category": "Accessories", "Price": 49.99, "Cost": 21.00},
    {"Product": "Samsung T7 1TB Portable SSD", "Category": "Technology", "Sub_Category": "Accessories", "Price": 129.99, "Cost": 72.00},
    {"Product": "Apple AirPods Pro", "Category": "Technology", "Sub_Category": "Accessories", "Price": 249.00, "Cost": 160.00},
    # Furniture - Chairs
    {"Product": "Herman Miller Aeron Chair", "Category": "Furniture", "Sub_Category": "Chairs", "Price": 1195.00, "Cost": 750.00},
    {"Product": "Steelcase Gesture Chair", "Category": "Furniture", "Sub_Category": "Chairs", "Price": 1050.00, "Cost": 670.00},
    {"Product": "ErgoChair Pro", "Category": "Furniture", "Sub_Category": "Chairs", "Price": 499.00, "Cost": 310.00},
    {"Product": "Mesh High-Back Task Chair", "Category": "Furniture", "Sub_Category": "Chairs", "Price": 199.00, "Cost": 135.00},
    # Furniture - Tables
    {"Product": "Electric Standing Desk 60 inch", "Category": "Furniture", "Sub_Category": "Tables", "Price": 599.00, "Cost": 375.00},
    {"Product": "Solid Oak Conference Table", "Category": "Furniture", "Sub_Category": "Tables", "Price": 899.00, "Cost": 560.00},
    {"Product": "Compact Home Office Desk", "Category": "Furniture", "Sub_Category": "Tables", "Price": 279.00, "Cost": 175.00},
    {"Product": "Glass Top Coffee Table", "Category": "Furniture", "Sub_Category": "Tables", "Price": 229.00, "Cost": 145.00},
    # Furniture - Bookcases
    {"Product": "5-Tier Modular Bookcase", "Category": "Furniture", "Sub_Category": "Bookcases", "Price": 229.00, "Cost": 135.00},
    {"Product": "Corner Floating Wood Shelf", "Category": "Furniture", "Sub_Category": "Bookcases", "Price": 149.00, "Cost": 90.00},
    {"Product": "Industrial Metal Bookshelf", "Category": "Furniture", "Sub_Category": "Bookcases", "Price": 349.00, "Cost": 210.00},
    # Office Supplies - Storage
    {"Product": "Steel 3-Drawer File Cabinet", "Category": "Office Supplies", "Sub_Category": "Storage", "Price": 179.00, "Cost": 105.00},
    {"Product": "Heavy Duty Plastic Storage Bin", "Category": "Office Supplies", "Sub_Category": "Storage", "Price": 34.99, "Cost": 17.00},
    {"Product": "Rolling Metal Utility Cart", "Category": "Office Supplies", "Sub_Category": "Storage", "Price": 79.99, "Cost": 44.00},
    {"Product": "Desktop Document Organizer", "Category": "Office Supplies", "Sub_Category": "Storage", "Price": 29.99, "Cost": 13.00},
    # Office Supplies - Paper
    {"Product": "Premium Multipurpose Paper Ream", "Category": "Office Supplies", "Sub_Category": "Paper", "Price": 24.99, "Cost": 11.50},
    {"Product": "Heavyweight Cardstock Pack", "Category": "Office Supplies", "Sub_Category": "Paper", "Price": 17.99, "Cost": 8.00},
    {"Product": "Glossy Photo Paper (100 Sheets)", "Category": "Office Supplies", "Sub_Category": "Paper", "Price": 21.50, "Cost": 9.50},
    {"Product": "Recycled Copy Paper Case", "Category": "Office Supplies", "Sub_Category": "Paper", "Price": 48.00, "Cost": 25.00},
    # Office Supplies - Binders
    {"Product": "Heavy-Duty 3-Ring Binder 2-inch", "Category": "Office Supplies", "Sub_Category": "Binders", "Price": 14.50, "Cost": 5.80},
    {"Product": "Presentation Folder 25-Pack", "Category": "Office Supplies", "Sub_Category": "Binders", "Price": 12.99, "Cost": 4.80},
    {"Product": "Archival Zipper Ring Binder", "Category": "Office Supplies", "Sub_Category": "Binders", "Price": 27.50, "Cost": 12.20},
    # Office Supplies - Art
    {"Product": "Dual-Tip Brush Marker Set 48ct", "Category": "Office Supplies", "Sub_Category": "Art", "Price": 44.99, "Cost": 20.00},
    {"Product": "Hardcover Sketchbook & Pencil Set", "Category": "Office Supplies", "Sub_Category": "Art", "Price": 26.50, "Cost": 11.00},
    {"Product": "Precision Drafting Compass & Ruler", "Category": "Office Supplies", "Sub_Category": "Art", "Price": 18.99, "Cost": 7.50}
]

# Geographic locations mapping
GEO_LOCATIONS = [
    {"Region": "North", "State": "Illinois", "City": "Chicago"},
    {"Region": "North", "State": "Illinois", "City": "Naperville"},
    {"Region": "North", "State": "Ohio", "City": "Columbus"},
    {"Region": "North", "State": "Ohio", "City": "Cleveland"},
    {"Region": "North", "State": "Michigan", "City": "Detroit"},
    {"Region": "North", "State": "Michigan", "City": "Grand Rapids"},
    {"Region": "North", "State": "Minnesota", "City": "Minneapolis"},
    {"Region": "South", "State": "Texas", "City": "Houston"},
    {"Region": "South", "State": "Texas", "City": "Austin"},
    {"Region": "South", "State": "Texas", "City": "Dallas"},
    {"Region": "South", "State": "Florida", "City": "Miami"},
    {"Region": "South", "State": "Florida", "City": "Orlando"},
    {"Region": "South", "State": "Georgia", "City": "Atlanta"},
    {"Region": "South", "State": "North Carolina", "City": "Charlotte"},
    {"Region": "East", "State": "New York", "City": "New York City"},
    {"Region": "East", "State": "New York", "City": "Buffalo"},
    {"Region": "East", "State": "Pennsylvania", "City": "Philadelphia"},
    {"Region": "East", "State": "Pennsylvania", "City": "Pittsburgh"},
    {"Region": "East", "State": "Massachusetts", "City": "Boston"},
    {"Region": "East", "State": "New Jersey", "City": "Newark"},
    {"Region": "West", "State": "California", "City": "Los Angeles"},
    {"Region": "West", "State": "California", "City": "San Francisco"},
    {"Region": "West", "State": "California", "City": "San Diego"},
    {"Region": "West", "State": "Washington", "City": "Seattle"},
    {"Region": "West", "State": "Oregon", "City": "Portland"},
    {"Region": "West", "State": "Colorado", "City": "Denver"}
]

FIRST_NAMES = [
    "James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda",
    "David", "Elizabeth", "William", "Barbara", "Richard", "Susan", "Joseph", "Jessica",
    "Thomas", "Sarah", "Charles", "Karen", "Christopher", "Nancy", "Daniel", "Lisa",
    "Matthew", "Betty", "Anthony", "Margaret", "Mark", "Sandra", "Donald", "Ashley",
    "Steven", "Kimberly", "Paul", "Emily", "Andrew", "Donna", "Joshua", "Michelle",
    "Kenneth", "Dorothy", "Kevin", "Carol", "Brian", "Amanda", "George", "Melissa",
    "Aarav", "Priya", "Ananya", "Rohan", "Vikram", "Sneha", "Aditya", "Neha", "Arjun", "Pooja"
]

LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
    "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
    "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker",
    "Sharma", "Verma", "Patel", "Reddy", "Mehta", "Nair", "Kapoor", "Gupta", "Deshmukh"
]

PAYMENT_MODES = ["Credit Card", "Debit Card", "UPI / Net Banking", "Cash on Delivery"]
PAYMENT_WEIGHTS = [0.45, 0.25, 0.20, 0.10]

DISCOUNT_OPTIONS = [0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.35, 0.50]
DISCOUNT_WEIGHTS = [0.35, 0.22, 0.18, 0.11, 0.07, 0.04, 0.02, 0.01]

QUANTITY_OPTIONS = [1, 2, 3, 4, 5, 6, 7, 8]
QUANTITY_WEIGHTS = [0.38, 0.26, 0.16, 0.09, 0.05, 0.03, 0.02, 0.01]

def build_customer_pool(num_customers=500):
    customers = []
    for i in range(1, num_customers + 1):
        c_id = f"CUST-{10000 + i}"
        fn = random.choice(FIRST_NAMES)
        ln = random.choice(LAST_NAMES)
        customers.append({"Customer_ID": c_id, "Customer_Name": f"{fn} {ln}"})
    return customers

def generate_synthetic_sales_data(target_records=7200):
    """
    Generates realistic sales transactions spanning 2022-01-01 to 2025-12-31.
    """
    customers = build_customer_pool(550)
    records = []
    start_date = datetime(2022, 1, 1)
    end_date = datetime(2025, 12, 31)
    total_days = (end_date - start_date).days

    order_counter = 10001
    
    for _ in range(target_records):
        # Seasonality model: Q4 (Oct-Dec) higher sales, Q1 slightly lower
        # Choose a random day with Q4 boost
        day_offset = random.randint(0, total_days)
        order_date = start_date + timedelta(days=day_offset)
        
        # Q4 boost resampling: 30% chance to shift to Q4 of same year
        if random.random() < 0.25:
            q4_day = random.randint(274, 364) # roughly Oct-Dec
            order_date = datetime(order_date.year, 1, 1) + timedelta(days=min(q4_day, 364))

        cust = random.choice(customers)
        prod = random.choice(PRODUCT_CATALOG)
        geo = random.choice(GEO_LOCATIONS)
        pay_mode = random.choices(PAYMENT_MODES, weights=PAYMENT_WEIGHTS, k=1)[0]
        
        qty = random.choices(QUANTITY_OPTIONS, weights=QUANTITY_WEIGHTS, k=1)[0]
        discount = random.choices(DISCOUNT_OPTIONS, weights=DISCOUNT_WEIGHTS, k=1)[0]
        
        base_price = prod["Price"]
        base_cost = prod["Cost"]
        
        # Calculate gross and net sales
        gross_sales = base_price * qty
        sales = round(gross_sales * (1.0 - discount), 2)
        
        # Total cost with minor random variation in handling/shipping overhead
        overhead_pct = random.uniform(0.02, 0.06)
        total_cost = (base_cost * qty) + (sales * overhead_pct)
        
        # Profit = Sales - Cost. Note: with high discounts (>20%), profit can easily become negative
        profit = round(sales - total_cost, 2)
        
        order_id = f"ORD-{order_date.year}-{order_counter}"
        # Some orders have multiple line items (same Order_ID)
        if random.random() > 0.35:
            order_counter += 1

        records.append({
            "Order_ID": order_id,
            "Order_Date": order_date.strftime("%Y-%m-%d"),
            "Customer_ID": cust["Customer_ID"],
            "Customer_Name": cust["Customer_Name"],
            "Product": prod["Product"],
            "Category": prod["Category"],
            "Sub_Category": prod["Sub_Category"],
            "Region": geo["Region"],
            "State": geo["State"],
            "City": geo["City"],
            "Sales": sales,
            "Quantity": qty,
            "Discount": discount,
            "Profit": profit,
            "Payment_Mode": pay_mode
        })
    
    df = pd.DataFrame(records)
    
    # Intentionally inject real-world imperfections for data cleaning demonstration:
    # 1. Exact duplicates (~75 rows)
    duplicate_rows = df.sample(n=75, random_state=42)
    df = pd.concat([df, duplicate_rows], ignore_index=True)
    
    # 2. Whitespace issues in City/State/Payment_Mode
    ws_indices = df.sample(n=60, random_state=101).index
    df.loc[ws_indices, "City"] = df.loc[ws_indices, "City"].apply(lambda x: f"  {x}  " if isinstance(x, str) else x)
    
    # 3. Inconsistent date formats (e.g., YYYY/MM/DD)
    date_indices = df.sample(n=80, random_state=202).index
    df.loc[date_indices, "Order_Date"] = df.loc[date_indices, "Order_Date"].apply(lambda x: x.replace("-", "/"))
    
    # 4. Small number of missing values in optional fields (e.g. Payment_Mode or Discount)
    null_indices = df.sample(n=15, random_state=303).index
    df.loc[null_indices, "Payment_Mode"] = np.nan
    
    # Shuffle dataframe
    df = df.sample(frac=1.0, random_state=42).reset_index(drop=True)
    return df

if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    raw_csv_path = os.path.join("data", "raw_sales_data.csv")
    df = generate_synthetic_sales_data(target_records=7300)
    df.to_csv(raw_csv_path, index=False)
    print(f"Generated {len(df)} raw records and saved to {raw_csv_path}.")
