"""
Database Operations Module
Project: Sales Performance Analytics Dashboard
Handles MySQL connectivity, table initialization, bulk CSV ingestion,
and analytical query execution with graceful error recovery.
"""

import os
import logging
from typing import Optional, Dict, Any, Tuple
import pandas as pd
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)


def get_db_config() -> Dict[str, Any]:
    """
    Retrieves database credentials from environment variables.
    """
    return {
        "host": os.getenv("DB_HOST", "localhost"),
        "port": int(os.getenv("DB_PORT", 3306)),
        "user": os.getenv("DB_USER", "root"),
        "password": os.getenv("DB_PASSWORD", ""),
        "database": os.getenv("DB_NAME", "sales_analytics")
    }


def get_db_connection(include_database: bool = True):
    """
    Establishes and returns a MySQL connection.
    Returns (connection, None) on success or (None, error_message) on failure.
    """
    try:
        import mysql.connector
        from mysql.connector import Error
    except ImportError:
        return None, "mysql-connector-python package is not installed."

    config = get_db_config()
    conn_params = {
        "host": config["host"],
        "port": config["port"],
        "user": config["user"],
        "password": config["password"]
    }
    if include_database:
        conn_params["database"] = config["database"]

    try:
        connection = mysql.connector.connect(**conn_params)
        if connection.is_connected():
            return connection, None
    except Error as e:
        return None, f"MySQL Connection Error: {str(e)}"
    except Exception as ex:
        return None, f"Unexpected error: {str(ex)}"

    return None, "Unable to establish MySQL connection."


def test_connection() -> Dict[str, Any]:
    """
    Checks whether MySQL database is accessible.
    """
    conn, err = get_db_connection(include_database=True)
    if conn:
        conn.close()
        return {"connected": True, "message": "Successfully connected to MySQL database."}
    
    # Try connecting without database to see if server is online but DB not yet created
    server_conn, server_err = get_db_connection(include_database=False)
    if server_conn:
        server_conn.close()
        return {
            "connected": False,
            "server_available": True,
            "message": "MySQL server is running, but database 'sales_analytics' is not yet created."
        }
        
    return {"connected": False, "server_available": False, "message": err}


def init_database(schema_path: str = "database/schema.sql") -> Tuple[bool, str]:
    """
    Executes schema DDL script to initialize database and tables.
    """
    if not os.path.exists(schema_path):
        return False, f"Schema file not found at {schema_path}"
        
    conn, err = get_db_connection(include_database=False)
    if not conn:
        return False, f"Cannot connect to MySQL server: {err}"
        
    try:
        cursor = conn.cursor()
        with open(schema_path, "r", encoding="utf-8") as f:
            sql_script = f.read()
            
        statements = [stmt.strip() for stmt in sql_script.split(";") if stmt.strip()]
        for stmt in statements:
            cursor.execute(stmt)
            
        conn.commit()
        cursor.close()
        conn.close()
        return True, "Database and schema initialized successfully."
    except Exception as e:
        return False, f"Failed to initialize schema: {str(e)}"


def load_csv_to_mysql(csv_path: str = "data/sales_data.csv", batch_size: int = 1000) -> Tuple[bool, str]:
    """
    Ingests cleaned sales records into MySQL `sales_data` table in batches.
    """
    if not os.path.exists(csv_path):
        return False, f"CSV dataset not found at {csv_path}"
        
    conn, err = get_db_connection(include_database=True)
    if not conn:
        return False, f"MySQL connection failed: {err}"
        
    try:
        df = pd.read_csv(csv_path)
        cursor = conn.cursor()
        
        # Truncate existing table
        cursor.execute("TRUNCATE TABLE sales_data;")
        
        insert_query = """
        INSERT INTO sales_data (
            Order_ID, Order_Date, Customer_ID, Customer_Name,
            Product, Category, Sub_Category, Region, State, City,
            Sales, Quantity, Discount, Profit, Payment_Mode,
            Year, Month, Month_Name, Quarter,
            Profit_Margin, Sales_Per_Unit, Order_Value
        ) VALUES (
            %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s,
            %s, %s, %s, %s,
            %s, %s, %s
        )
        """
        
        columns = [
            "Order_ID", "Order_Date", "Customer_ID", "Customer_Name",
            "Product", "Category", "Sub_Category", "Region", "State", "City",
            "Sales", "Quantity", "Discount", "Profit", "Payment_Mode",
            "Year", "Month", "Month_Name", "Quarter",
            "Profit_Margin", "Sales_Per_Unit", "Order_Value"
        ]
        
        records = df[columns].values.tolist()
        
        for i in range(0, len(records), batch_size):
            batch = records[i:i + batch_size]
            cursor.executemany(insert_query, batch)
            conn.commit()
            
        cursor.close()
        conn.close()
        return True, f"Successfully loaded {len(records)} records into MySQL sales_data table."
    except Exception as e:
        return False, f"Data ingestion failed: {str(e)}"


def execute_query(query: str, params: Optional[tuple] = None) -> Tuple[Optional[pd.DataFrame], Optional[str]]:
    """
    Executes a SELECT SQL query and returns results as a Pandas DataFrame.
    """
    conn, err = get_db_connection(include_database=True)
    if not conn:
        return None, err
        
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params or ())
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        return pd.DataFrame(rows), None
    except Exception as e:
        return None, f"Query execution error: {str(e)}"
