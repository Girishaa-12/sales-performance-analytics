"""
Data Analysis & Business Logic Module
Project: Sales Performance Analytics Dashboard
Calculates KPIs, growth rates, aggregations, customer & product metrics,
and dynamically generates data-driven business insights.
"""

from typing import Dict, Any, Optional, Tuple
import pandas as pd
import numpy as np


def calculate_kpis(df: pd.DataFrame, prev_df: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
    """
    Calculates executive KPIs and dynamic period-over-period comparisons.
    """
    if df.empty:
        return {
            "total_sales": 0.0,
            "total_profit": 0.0,
            "total_orders": 0,
            "quantity_sold": 0,
            "avg_order_value": 0.0,
            "profit_margin_pct": 0.0,
            "sales_growth_pct": None,
            "profit_growth_pct": None,
            "orders_growth_pct": None
        }

    total_sales = float(df["Sales"].sum())
    total_profit = float(df["Profit"].sum())
    total_orders = int(df["Order_ID"].nunique())
    quantity_sold = int(df["Quantity"].sum())
    
    avg_order_value = round(total_sales / total_orders, 2) if total_orders > 0 else 0.0
    profit_margin_pct = round((total_profit / total_sales) * 100.0, 2) if total_sales > 0 else 0.0

    sales_growth = None
    profit_growth = None
    orders_growth = None

    if prev_df is not None and not prev_df.empty:
        prev_sales = float(prev_df["Sales"].sum())
        prev_profit = float(prev_df["Profit"].sum())
        prev_orders = int(prev_df["Order_ID"].nunique())

        if prev_sales > 0:
            sales_growth = round(((total_sales - prev_sales) / prev_sales) * 100.0, 2)
        if prev_profit != 0:
            profit_growth = round(((total_profit - prev_profit) / abs(prev_profit)) * 100.0, 2)
        if prev_orders > 0:
            orders_growth = round(((total_orders - prev_orders) / prev_orders) * 100.0, 2)

    return {
        "total_sales": round(total_sales, 2),
        "total_profit": round(total_profit, 2),
        "total_orders": total_orders,
        "quantity_sold": quantity_sold,
        "avg_order_value": avg_order_value,
        "profit_margin_pct": profit_margin_pct,
        "sales_growth_pct": sales_growth,
        "profit_growth_pct": profit_growth,
        "orders_growth_pct": orders_growth
    }


def get_monthly_sales_trend(df: pd.DataFrame) -> pd.DataFrame:
    """
    Returns monthly aggregated sales, profit, orders, and profit margin.
    """
    if df.empty:
        return pd.DataFrame(columns=["Year_Month", "Year", "Month", "Month_Name", "Sales", "Profit", "Orders", "Margin_Pct"])
        
    trend = df.groupby(["Year", "Month", "Month_Name"], as_index=False).agg(
        Sales=("Sales", "sum"),
        Profit=("Profit", "sum"),
        Orders=("Order_ID", "nunique"),
        Quantity=("Quantity", "sum")
    ).sort_values(by=["Year", "Month"]).reset_index(drop=True)

    trend["Year_Month"] = trend["Year"].astype(str) + "-" + trend["Month"].astype(str).str.zfill(2)
    trend["Margin_Pct"] = np.where(
        trend["Sales"] > 0,
        (trend["Profit"] / trend["Sales"]) * 100.0,
        0.0
    ).round(2)
    trend["Sales"] = trend["Sales"].round(2)
    trend["Profit"] = trend["Profit"].round(2)
    return trend


def calculate_sales_growth(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates Month-over-Month (MoM) and Year-over-Year (YoY) growth percentages.
    """
    trend = get_monthly_sales_trend(df)
    if trend.empty:
        return trend
        
    trend["MoM_Sales_Growth"] = trend["Sales"].pct_change() * 100.0
    trend["MoM_Profit_Growth"] = trend["Profit"].pct_change() * 100.0
    
    # YoY growth: shift 12 months if continuous
    trend["YoY_Sales_Growth"] = trend["Sales"].pct_change(periods=12) * 100.0
    
    trend["MoM_Sales_Growth"] = trend["MoM_Sales_Growth"].round(2)
    trend["MoM_Profit_Growth"] = trend["MoM_Profit_Growth"].round(2)
    trend["YoY_Sales_Growth"] = trend["YoY_Sales_Growth"].round(2)
    
    return trend


def get_regional_breakdown(df: pd.DataFrame) -> pd.DataFrame:
    """
    Returns regional performance metrics and percentage contribution.
    """
    if df.empty:
        return pd.DataFrame(columns=["Region", "Sales", "Profit", "Orders", "Margin_Pct", "Contribution_Pct"])
        
    total_sales = df["Sales"].sum()
    regional = df.groupby("Region", as_index=False).agg(
        Sales=("Sales", "sum"),
        Profit=("Profit", "sum"),
        Orders=("Order_ID", "nunique"),
        Quantity=("Quantity", "sum")
    ).sort_values(by="Sales", ascending=False).reset_index(drop=True)
    
    regional["Margin_Pct"] = np.where(
        regional["Sales"] > 0,
        (regional["Profit"] / regional["Sales"]) * 100.0,
        0.0
    ).round(2)
    
    regional["Contribution_Pct"] = (
        (regional["Sales"] / total_sales) * 100.0 if total_sales > 0 else 0.0
    ).round(2)
    regional["Sales"] = regional["Sales"].round(2)
    regional["Profit"] = regional["Profit"].round(2)
    return regional


def get_state_breakdown(df: pd.DataFrame, region: Optional[str] = None) -> pd.DataFrame:
    """
    Returns state-level performance metrics, optionally filtered by region.
    """
    data = df if region is None else df[df["Region"] == region]
    if data.empty:
        return pd.DataFrame(columns=["State", "Region", "Sales", "Profit", "Orders", "Margin_Pct"])
        
    state_df = data.groupby(["State", "Region"], as_index=False).agg(
        Sales=("Sales", "sum"),
        Profit=("Profit", "sum"),
        Orders=("Order_ID", "nunique"),
        Quantity=("Quantity", "sum")
    ).sort_values(by="Sales", ascending=False).reset_index(drop=True)
    
    state_df["Margin_Pct"] = np.where(
        state_df["Sales"] > 0,
        (state_df["Profit"] / state_df["Sales"]) * 100.0,
        0.0
    ).round(2)
    state_df["Sales"] = state_df["Sales"].round(2)
    state_df["Profit"] = state_df["Profit"].round(2)
    return state_df


def get_product_rankings(
    df: pd.DataFrame,
    metric: str = "Sales",
    top_n: int = 10,
    ascending: bool = False
) -> pd.DataFrame:
    """
    Returns top or bottom N products ranked dynamically by Sales, Profit, or Quantity.
    """
    if df.empty or metric not in ["Sales", "Profit", "Quantity"]:
        return pd.DataFrame(columns=["Product", "Category", "Sub_Category", "Sales", "Profit", "Quantity", "Margin_Pct"])
        
    grouped = df.groupby(["Product", "Category", "Sub_Category"], as_index=False).agg(
        Sales=("Sales", "sum"),
        Profit=("Profit", "sum"),
        Quantity=("Quantity", "sum")
    )
    
    grouped["Margin_Pct"] = np.where(
        grouped["Sales"] > 0,
        (grouped["Profit"] / grouped["Sales"]) * 100.0,
        0.0
    ).round(2)
    grouped["Sales"] = grouped["Sales"].round(2)
    grouped["Profit"] = grouped["Profit"].round(2)
    
    ranked = grouped.sort_values(by=metric, ascending=ascending).head(top_n).reset_index(drop=True)
    return ranked


def get_category_metrics(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Returns aggregated metrics by Category and by Sub-Category.
    """
    if df.empty:
        cat_df = pd.DataFrame(columns=["Category", "Sales", "Profit", "Quantity", "Margin_Pct", "Contribution_Pct"])
        sub_df = pd.DataFrame(columns=["Category", "Sub_Category", "Sales", "Profit", "Quantity", "Margin_Pct"])
        return cat_df, sub_df
        
    total_sales = df["Sales"].sum()
    
    # Category level
    cat_df = df.groupby("Category", as_index=False).agg(
        Sales=("Sales", "sum"),
        Profit=("Profit", "sum"),
        Quantity=("Quantity", "sum"),
        Orders=("Order_ID", "nunique")
    ).sort_values(by="Sales", ascending=False).reset_index(drop=True)
    
    cat_df["Margin_Pct"] = np.where(cat_df["Sales"] > 0, (cat_df["Profit"] / cat_df["Sales"]) * 100.0, 0.0).round(2)
    cat_df["Contribution_Pct"] = ((cat_df["Sales"] / total_sales) * 100.0 if total_sales > 0 else 0.0).round(2)
    cat_df["Sales"] = cat_df["Sales"].round(2)
    cat_df["Profit"] = cat_df["Profit"].round(2)
    
    # Sub-Category level
    sub_df = df.groupby(["Category", "Sub_Category"], as_index=False).agg(
        Sales=("Sales", "sum"),
        Profit=("Profit", "sum"),
        Quantity=("Quantity", "sum"),
        Orders=("Order_ID", "nunique")
    ).sort_values(by="Sales", ascending=False).reset_index(drop=True)
    
    sub_df["Margin_Pct"] = np.where(sub_df["Sales"] > 0, (sub_df["Profit"] / sub_df["Sales"]) * 100.0, 0.0).round(2)
    sub_df["Sales"] = sub_df["Sales"].round(2)
    sub_df["Profit"] = sub_df["Profit"].round(2)
    
    return cat_df, sub_df


def get_customer_metrics(df: pd.DataFrame, top_n: int = 10) -> Dict[str, pd.DataFrame]:
    """
    Returns customer leaderboards: Top by Sales, Top by Profit, Top by Orders.
    """
    if df.empty:
        empty_df = pd.DataFrame(columns=["Customer_ID", "Customer_Name", "Orders", "Items", "Sales", "Profit", "AOV", "Margin_Pct"])
        return {"by_sales": empty_df, "by_profit": empty_df, "by_orders": empty_df}
        
    cust = df.groupby(["Customer_ID", "Customer_Name"], as_index=False).agg(
        Orders=("Order_ID", "nunique"),
        Items=("Quantity", "sum"),
        Sales=("Sales", "sum"),
        Profit=("Profit", "sum")
    )
    cust["AOV"] = np.where(cust["Orders"] > 0, cust["Sales"] / cust["Orders"], 0.0).round(2)
    cust["Margin_Pct"] = np.where(cust["Sales"] > 0, (cust["Profit"] / cust["Sales"]) * 100.0, 0.0).round(2)
    cust["Sales"] = cust["Sales"].round(2)
    cust["Profit"] = cust["Profit"].round(2)
    
    by_sales = cust.sort_values(by="Sales", ascending=False).head(top_n).reset_index(drop=True)
    by_profit = cust.sort_values(by="Profit", ascending=False).head(top_n).reset_index(drop=True)
    by_orders = cust.sort_values(by="Orders", ascending=False).head(top_n).reset_index(drop=True)
    
    return {
        "by_sales": by_sales,
        "by_profit": by_profit,
        "by_orders": by_orders
    }


def get_discount_vs_profit_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Prepares transaction-level and binned data for discount-profit elasticity analysis.
    """
    if df.empty:
        return pd.DataFrame()
        
    bins = [-0.01, 0.0, 0.10, 0.20, 0.30, 1.0]
    labels = ["0% (No Discount)", "1% - 10%", "11% - 20%", "21% - 30%", "> 30% (High Discount)"]
    
    df_copy = df.copy()
    df_copy["Discount_Bracket"] = pd.cut(df_copy["Discount"], bins=bins, labels=labels)
    
    binned = df_copy.groupby("Discount_Bracket", observed=False, as_index=False).agg(
        Transactions=("Order_ID", "count"),
        Sales=("Sales", "sum"),
        Profit=("Profit", "sum"),
        Avg_Discount=("Discount", "mean")
    )
    binned["Margin_Pct"] = np.where(binned["Sales"] > 0, (binned["Profit"] / binned["Sales"]) * 100.0, 0.0).round(2)
    binned["Sales"] = binned["Sales"].round(2)
    binned["Profit"] = binned["Profit"].round(2)
    binned["Avg_Discount_Pct"] = (binned["Avg_Discount"] * 100.0).round(1)
    
    return binned


def generate_business_insights(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Generates dynamic, data-driven business insights from the filtered dataset.
    No hard-coded values; all metrics and narratives are calculated dynamically.
    """
    if df.empty:
        return {"status": "empty", "message": "No data available for the selected filters."}

    total_sales = float(df["Sales"].sum())
    total_profit = float(df["Profit"].sum())
    overall_margin = round((total_profit / total_sales) * 100.0, 2) if total_sales > 0 else 0.0
    avg_discount = round(float(df["Discount"].mean()) * 100.0, 1)

    # Regional analysis
    reg = df.groupby("Region")["Sales"].sum()
    best_region = reg.idxmax() if not reg.empty else "N/A"
    best_region_sales = reg.max() if not reg.empty else 0.0
    best_region_share = round((best_region_sales / total_sales) * 100.0, 1) if total_sales > 0 else 0.0
    
    weakest_region = reg.idxmin() if not reg.empty else "N/A"
    weakest_region_sales = reg.min() if not reg.empty else 0.0
    weakest_region_share = round((weakest_region_sales / total_sales) * 100.0, 1) if total_sales > 0 else 0.0

    # Category analysis
    cat_sales = df.groupby("Category")["Sales"].sum()
    cat_profit = df.groupby("Category")["Profit"].sum()
    best_cat_sales = cat_sales.idxmax() if not cat_sales.empty else "N/A"
    best_cat_sales_share = round((cat_sales.max() / total_sales) * 100.0, 1) if total_sales > 0 else 0.0
    
    most_profitable_cat = cat_profit.idxmax() if not cat_profit.empty else "N/A"
    most_profitable_cat_margin = round((cat_profit.max() / cat_sales[most_profitable_cat]) * 100.0, 1) if not cat_profit.empty and cat_sales[most_profitable_cat] > 0 else 0.0

    # Product rankings
    prod_sales = df.groupby("Product")["Sales"].sum()
    prod_profit = df.groupby("Product")["Profit"].sum()
    top_prod = prod_sales.idxmax() if not prod_sales.empty else "N/A"
    top_prod_sales = round(float(prod_sales.max()), 2) if not prod_sales.empty else 0.0
    
    lowest_profit_prod = prod_profit.idxmin() if not prod_profit.empty else "N/A"
    lowest_profit_val = round(float(prod_profit.min()), 2) if not prod_profit.empty else 0.0

    # Monthly performance
    monthly = df.groupby(["Year", "Month_Name"], as_index=False).agg(
        Sales=("Sales", "sum"),
        Profit=("Profit", "sum")
    )
    if not monthly.empty:
        best_month_row = monthly.loc[monthly["Sales"].idxmax()]
        highest_sales_month = f"{best_month_row['Month_Name']} {best_month_row['Year']}"
        highest_sales_month_val = round(float(best_month_row["Sales"]), 2)
        
        best_profit_row = monthly.loc[monthly["Profit"].idxmax()]
        highest_profit_month = f"{best_profit_row['Month_Name']} {best_profit_row['Year']}"
        highest_profit_month_val = round(float(best_profit_row["Profit"]), 2)
    else:
        highest_sales_month = "N/A"
        highest_sales_month_val = 0.0
        highest_profit_month = "N/A"
        highest_profit_month_val = 0.0

    # Discount impact analysis
    high_discount_df = df[df["Discount"] > 0.20]
    low_discount_df = df[df["Discount"] <= 0.20]
    
    high_disc_margin = round((high_discount_df["Profit"].sum() / high_discount_df["Sales"].sum()) * 100.0, 1) if not high_discount_df.empty and high_discount_df["Sales"].sum() > 0 else 0.0
    low_disc_margin = round((low_discount_df["Profit"].sum() / low_discount_df["Sales"].sum()) * 100.0, 1) if not low_discount_df.empty and low_discount_df["Sales"].sum() > 0 else 0.0

    # Margin health category
    if overall_margin >= 25.0:
        margin_health = "Exceptional"
        margin_color = "green"
    elif overall_margin >= 18.0:
        margin_health = "Healthy"
        margin_color = "blue"
    elif overall_margin >= 10.0:
        margin_health = "Moderate"
        margin_color = "orange"
    else:
        margin_health = "Compressed / Critical"
        margin_color = "red"

    # Dynamic actionable recommendations
    recommendations = []
    if high_disc_margin < 5.0:
        recommendations.append(
            f"**Discount Governance**: Transactions with discounts > 20% yield only a **{high_disc_margin}%** margin compared to **{low_disc_margin}%** for lower discounts. Cap discretionary discounting to protect gross margins."
        )
    if lowest_profit_val < 0:
        recommendations.append(
            f"**Loss-Making Product Audit**: Product '{lowest_profit_prod}' generated a net loss of **${abs(lowest_profit_val):,.2f}**. Review vendor supplier costs or adjust pricing structure immediately."
        )
    recommendations.append(
        f"**Regional Optimization**: **{best_region}** dominates revenue with **{best_region_share}%** share. Replicate sales enablement tactics from {best_region} to boost underperforming **{weakest_region}** ({weakest_region_share}% share)."
    )
    recommendations.append(
        f"**Category Focus**: Prioritize **{most_profitable_cat}**, which delivers the strongest profitability at **{most_profitable_cat_margin}%** profit margin."
    )

    return {
        "status": "success",
        "best_region": best_region,
        "best_region_sales": best_region_sales,
        "best_region_share": best_region_share,
        "weakest_region": weakest_region,
        "weakest_region_sales": weakest_region_sales,
        "weakest_region_share": weakest_region_share,
        "best_category": best_cat_sales,
        "best_category_share": best_cat_sales_share,
        "most_profitable_category": most_profitable_cat,
        "most_profitable_category_margin": most_profitable_cat_margin,
        "top_product": top_prod,
        "top_product_sales": top_prod_sales,
        "lowest_profit_product": lowest_profit_prod,
        "lowest_profit_value": lowest_profit_val,
        "highest_sales_month": highest_sales_month,
        "highest_sales_month_val": highest_sales_month_val,
        "highest_profit_month": highest_profit_month,
        "highest_profit_month_val": highest_profit_month_val,
        "avg_discount_pct": avg_discount,
        "overall_profit_margin_pct": overall_margin,
        "margin_health": margin_health,
        "margin_color": margin_color,
        "high_discount_margin_pct": high_disc_margin,
        "low_discount_margin_pct": low_disc_margin,
        "recommendations": recommendations
    }
