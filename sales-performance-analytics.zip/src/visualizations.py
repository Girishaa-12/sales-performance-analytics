"""
Interactive Visualizations Module
Project: Sales Performance Analytics Dashboard
Provides publication-grade Plotly interactive visualizations with
consistent enterprise themes, rich tooltips, and dynamic metrics.
"""

from typing import Optional
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np

# Enterprise Color Palette
PALETTE = {
    "primary": "#1E40AF",      # Enterprise Blue
    "secondary": "#3B82F6",    # Sky Blue
    "success": "#10B981",      # Emerald Green
    "danger": "#EF4444",       # Crimson Red
    "warning": "#F59E0B",      # Amber
    "purple": "#8B5CF6",       # Violet
    "dark": "#1E293B",         # Slate Dark
    "neutral": "#64748B",      # Slate Neutral
    "bg": "#FFFFFF",
    "grid": "#F1F5F9"
}

FONT_FAMILY = "Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, sans-serif"


def _apply_theme(fig: go.Figure, title: str = "", height: int = 400) -> go.Figure:
    """
    Applies consistent enterprise styling to a Plotly figure.
    """
    fig.update_layout(
        title=dict(
            text=f"<b>{title}</b>" if title else "",
            font=dict(family=FONT_FAMILY, size=16, color=PALETTE["dark"]),
            x=0.01,
            y=0.96
        ),
        font=dict(family=FONT_FAMILY, size=12, color=PALETTE["neutral"]),
        plot_bgcolor="rgba(248, 250, 252, 0.5)",
        paper_bgcolor="#FFFFFF",
        margin=dict(l=40, r=30, t=50, b=40),
        height=height,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1,
            font=dict(size=11)
        ),
        hoverlabel=dict(
            bgcolor="#1E293B",
            font_size=12,
            font_family=FONT_FAMILY,
            font_color="#FFFFFF"
        )
    )
    fig.update_xaxes(
        showgrid=True,
        gridwidth=1,
        gridcolor="#E2E8F0",
        linecolor="#CBD5E1",
        zeroline=False
    )
    fig.update_yaxes(
        showgrid=True,
        gridwidth=1,
        gridcolor="#E2E8F0",
        linecolor="#CBD5E1",
        zeroline=False
    )
    return fig


def plot_monthly_sales_trend(trend_df: pd.DataFrame) -> go.Figure:
    """
    Line chart showing Monthly Sales Trend with rich hover tooltips.
    """
    if trend_df.empty:
        return _apply_theme(go.Figure(), "Monthly Sales Trend (No Data)")
        
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=trend_df["Year_Month"],
        y=trend_df["Sales"],
        mode="lines+markers",
        name="Sales ($)",
        line=dict(color=PALETTE["secondary"], width=3, shape="spline"),
        marker=dict(size=7, color=PALETTE["primary"]),
        customdata=np.stack((trend_df["Month_Name"], trend_df["Profit"], trend_df["Margin_Pct"]), axis=-1),
        hovertemplate=(
            "<b>Period: %{customdata[0]} %{x}</b><br>" +
            "Sales: $%{y:,.2f}<br>" +
            "Profit: $%{customdata[1]:,.2f}<br>" +
            "Margin: %{customdata[2]:.1f}%<extra></extra>"
        )
    ))

    fig = _apply_theme(fig, "Monthly Sales Trend", height=380)
    fig.update_yaxes(tickprefix="$", tickformat=",.0f")
    fig.update_xaxes(tickangle=-45)
    return fig


def plot_monthly_sales_vs_profit(trend_df: pd.DataFrame) -> go.Figure:
    """
    Dual-metric visualization comparing Monthly Sales (Bars) and Profit (Line).
    """
    if trend_df.empty:
        return _apply_theme(go.Figure(), "Monthly Sales vs Profit (No Data)")

    fig = make_subplots(specs=[[{"secondary_y": True}]])

    fig.add_trace(
        go.Bar(
            x=trend_df["Year_Month"],
            y=trend_df["Sales"],
            name="Sales ($)",
            marker_color="#93C5FD",
            opacity=0.85,
            hovertemplate="Period: %{x}<br>Sales: $%{y:,.2f}<extra></extra>"
        ),
        secondary_y=False
    )

    fig.add_trace(
        go.Scatter(
            x=trend_df["Year_Month"],
            y=trend_df["Profit"],
            name="Profit ($)",
            mode="lines+markers",
            line=dict(color=PALETTE["success"], width=3),
            marker=dict(size=6, color=PALETTE["success"]),
            hovertemplate="Period: %{x}<br>Profit: $%{y:,.2f}<extra></extra>"
        ),
        secondary_y=True
    )

    fig = _apply_theme(fig, "Monthly Sales vs. Profit Comparison", height=400)
    fig.update_yaxes(title_text="Sales ($)", secondary_y=False, tickprefix="$", tickformat=",.0f")
    fig.update_yaxes(title_text="Profit ($)", secondary_y=True, tickprefix="$", tickformat=",.0f")
    fig.update_xaxes(tickangle=-45)
    return fig


def plot_regional_performance(reg_df: pd.DataFrame) -> go.Figure:
    """
    Horizontal bar chart for Sales and Profit by Region.
    """
    if reg_df.empty:
        return _apply_theme(go.Figure(), "Regional Performance (No Data)")

    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        y=reg_df["Region"],
        x=reg_df["Sales"],
        name="Sales ($)",
        orientation="h",
        marker_color=PALETTE["secondary"],
        text=reg_df["Sales"].apply(lambda x: f"${x:,.0f}"),
        textposition="auto",
        hovertemplate="Region: %{y}<br>Sales: $%{x:,.2f}<br>Share: %{customdata:.1f}%<extra></extra>",
        customdata=reg_df["Contribution_Pct"]
    ))

    fig.add_trace(go.Bar(
        y=reg_df["Region"],
        x=reg_df["Profit"],
        name="Profit ($)",
        orientation="h",
        marker_color=PALETTE["success"],
        text=reg_df["Profit"].apply(lambda x: f"${x:,.0f}"),
        textposition="auto",
        hovertemplate="Region: %{y}<br>Profit: $%{x:,.2f}<br>Margin: %{customdata:.1f}%<extra></extra>",
        customdata=reg_df["Margin_Pct"]
    ))

    fig = _apply_theme(fig, "Sales and Profit by Region", height=350)
    fig.update_layout(barmode="group", yaxis=dict(autorange="reversed"))
    fig.update_xaxes(tickprefix="$", tickformat=",.0f")
    return fig


def plot_category_breakdown(cat_df: pd.DataFrame) -> go.Figure:
    """
    Donut chart of Category Sales Contribution.
    """
    if cat_df.empty:
        return _apply_theme(go.Figure(), "Category Contribution (No Data)")

    colors = [PALETTE["primary"], PALETTE["secondary"], PALETTE["purple"], PALETTE["success"]]
    fig = go.Figure(data=[go.Pie(
        labels=cat_df["Category"],
        values=cat_df["Sales"],
        hole=0.55,
        marker=dict(colors=colors[:len(cat_df)]),
        textinfo="label+percent",
        hovertemplate="Category: %{label}<br>Sales: $%{value:,.2f}<br>Share: %{percent}<extra></extra>"
    )])

    fig = _apply_theme(fig, "Sales Contribution by Category", height=350)
    fig.update_layout(showlegend=True)
    return fig


def plot_sub_category_sunburst(df: pd.DataFrame) -> go.Figure:
    """
    Hierarchical Sunburst chart showing Category -> Sub-Category revenue.
    """
    if df.empty:
        return _apply_theme(go.Figure(), "Category Hierarchy (No Data)")

    fig = px.sunburst(
        df,
        path=["Category", "Sub_Category"],
        values="Sales",
        color="Profit",
        color_continuous_scale="RdBu",
        title="Revenue & Profit Hierarchy (Category → Sub-Category)"
    )
    fig = _apply_theme(fig, "Category & Sub-Category Sunburst", height=420)
    return fig


def plot_product_rankings(
    ranked_df: pd.DataFrame,
    metric: str = "Sales",
    title: str = "Top Products"
) -> go.Figure:
    """
    Horizontal bar chart for top/bottom products sorted by selected metric.
    """
    if ranked_df.empty:
        return _apply_theme(go.Figure(), f"{title} (No Data)")

    color_col = PALETTE["success"] if metric == "Profit" else PALETTE["primary"]
    prefix = "$" if metric in ["Sales", "Profit"] else ""

    # Sort ascending for horizontal bar display (highest at top)
    df_plot = ranked_df.sort_values(by=metric, ascending=True)

    fig = go.Figure(go.Bar(
        x=df_plot[metric],
        y=df_plot["Product"],
        orientation="h",
        marker=dict(
            color=df_plot[metric],
            colorscale="Viridis" if metric == "Sales" else ("Temps" if metric == "Profit" else "Blues"),
            showscale=False
        ),
        text=df_plot[metric].apply(lambda x: f"{prefix}{x:,.0f}" if isinstance(x, (int, float)) else str(x)),
        textposition="inside",
        insidetextanchor="middle",
        customdata=np.stack((df_plot["Category"], df_plot["Profit_Margin"] if "Profit_Margin" in df_plot.columns else df_plot["Margin_Pct"]), axis=-1),
        hovertemplate=(
            "<b>%{y}</b><br>" +
            f"{metric}: {prefix}%{{x:,.2f}}<br>" +
            "Category: %{customdata[0]}<br>" +
            "Profit Margin: %{customdata[1]:.1f}%<extra></extra>"
        )
    ))

    fig = _apply_theme(fig, title, height=420)
    if prefix:
        fig.update_xaxes(tickprefix=prefix, tickformat=",.0f")
    fig.update_layout(margin=dict(l=160, r=20, t=50, b=40))
    return fig


def plot_discount_vs_profit(df: pd.DataFrame) -> go.Figure:
    """
    Scatter plot of Discount vs Profit showing margin erosion dynamics.
    """
    if df.empty:
        return _apply_theme(go.Figure(), "Discount vs. Profit (No Data)")

    # Sample if dataset is large for responsive rendering
    plot_df = df.sample(min(len(df), 1500), random_state=42) if len(df) > 1500 else df

    fig = px.scatter(
        plot_df,
        x="Discount",
        y="Profit",
        color="Category",
        size="Sales",
        hover_name="Product",
        hover_data={"Sales": ":$,.2f", "Discount": ":.0%", "Profit": ":$,.2f", "Category": True},
        color_discrete_sequence=[PALETTE["primary"], PALETTE["success"], PALETTE["warning"]],
        opacity=0.7
    )

    # Reference zero-profit line
    fig.add_hline(y=0, line_dash="dash", line_color=PALETTE["danger"], annotation_text="Break-Even (0 Profit)", annotation_position="bottom right")

    fig = _apply_theme(fig, "Discount Rate vs. Profit Realization (Margin Erosion)", height=450)
    fig.update_xaxes(tickformat=".0%", title_text="Discount Applied")
    fig.update_yaxes(tickprefix="$", tickformat=",.0f", title_text="Profit ($)")
    return fig


def plot_growth_trend(growth_df: pd.DataFrame) -> go.Figure:
    """
    Bar chart of Month-over-Month Sales Growth with conditional colors.
    """
    if growth_df.empty or "MoM_Sales_Growth" not in growth_df.columns:
        return _apply_theme(go.Figure(), "Sales Growth Trend (No Data)")

    valid = growth_df.dropna(subset=["MoM_Sales_Growth"]).copy()
    colors = [PALETTE["success"] if val >= 0 else PALETTE["danger"] for val in valid["MoM_Sales_Growth"]]

    fig = go.Figure(go.Bar(
        x=valid["Year_Month"],
        y=valid["MoM_Sales_Growth"],
        marker_color=colors,
        text=valid["MoM_Sales_Growth"].apply(lambda x: f"{x:+.1f}%"),
        textposition="outside",
        hovertemplate="Month: %{x}<br>MoM Growth: %{y:+.2f}%<extra></extra>"
    ))

    fig = _apply_theme(fig, "Month-over-Month Sales Growth (%)", height=380)
    fig.add_hline(y=0, line_color="#94A3B8", line_width=1)
    fig.update_yaxes(ticksuffix="%", title_text="Growth Rate (%)")
    fig.update_xaxes(tickangle=-45)
    return fig
