"""
Data Preparation and Cleaning Pipeline
Project: Sales Performance Analytics Dashboard
Provides reusable functions for loading, profiling, cleaning,
validating, and feature-engineering sales data.
"""

import os
import logging
from typing import Dict, Any, Tuple
import pandas as pd
import numpy as np

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

REQUIRED_COLUMNS = [
    "Order_ID", "Order_Date", "Customer_ID", "Customer_Name",
    "Product", "Category", "Sub_Category", "Region", "State",
    "City", "Sales", "Quantity", "Discount", "Profit", "Payment_Mode"
]


def load_data(filepath: str) -> pd.DataFrame:
    """
    Loads dataset from a CSV or Excel file with validation.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"File not found at path: {filepath}")
    
    file_ext = os.path.splitext(filepath)[1].lower()
    if file_ext == ".csv":
        df = pd.read_csv(filepath)
    elif file_ext in [".xlsx", ".xls"]:
        df = pd.read_excel(filepath)
    else:
        raise ValueError(f"Unsupported file format: {file_ext}. Please provide a .csv or .xlsx file.")
    
    logger.info("Loaded dataset from %s with shape %s", filepath, df.shape)
    return df


def profile_data(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Performs data profiling: returns shape, column nulls, duplicates, and memory usage.
    """
    profile = {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "memory_mb": round(df.memory_usage(deep=True).sum() / (1024 * 1024), 2),
        "total_nulls": int(df.isnull().sum().sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "columns_summary": {}
    }
    
    for col in df.columns:
        profile["columns_summary"][col] = {
            "dtype": str(df[col].dtype),
            "null_count": int(df[col].isnull().sum()),
            "null_pct": round(float(df[col].isnull().mean()) * 100, 2),
            "unique_values": int(df[col].nunique())
        }
    return profile


def detect_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """
    Returns a dataframe summary of columns containing missing values.
    """
    null_counts = df.isnull().sum()
    null_pct = (df.isnull().mean() * 100).round(2)
    missing_summary = pd.DataFrame({
        "Missing_Count": null_counts,
        "Percentage": null_pct
    })
    return missing_summary[missing_summary["Missing_Count"] > 0]


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """
    Handles missing values:
    - Critical identifiers (Order_ID, Customer_ID, Sales, Profit) dropped if null.
    - Categorical columns imputed with mode or 'Unknown'.
    - Numeric metrics imputed with median or 0.
    """
    df_clean = df.copy()
    
    # Drop rows missing crucial keys
    critical_cols = ["Order_ID", "Sales", "Profit"]
    df_clean = df_clean.dropna(subset=[c for c in critical_cols if c in df_clean.columns])
    
    # Impute categorical
    categorical_cols = ["Payment_Mode", "Region", "State", "City", "Category", "Sub_Category"]
    for col in categorical_cols:
        if col in df_clean.columns and df_clean[col].isnull().any():
            mode_val = df_clean[col].mode()
            fill_val = mode_val[0] if not mode_val.empty else "Unknown"
            df_clean[col] = df_clean[col].fillna(fill_val)
            logger.info("Imputed missing values in '%s' with '%s'", col, fill_val)
            
    # Impute numeric
    numeric_cols = ["Discount", "Quantity"]
    for col in numeric_cols:
        if col in df_clean.columns and df_clean[col].isnull().any():
            median_val = df_clean[col].median()
            df_clean[col] = df_clean[col].fillna(median_val)
            logger.info("Imputed missing values in '%s' with %s", col, median_val)
            
    return df_clean


def detect_duplicates(df: pd.DataFrame, subset=None) -> int:
    """
    Returns the count of duplicate rows.
    """
    return int(df.duplicated(subset=subset).sum())


def remove_duplicates(df: pd.DataFrame, subset=None) -> pd.DataFrame:
    """
    Removes duplicate records from the dataframe.
    """
    initial_count = len(df)
    df_clean = df.drop_duplicates(subset=subset).reset_index(drop=True)
    removed_count = initial_count - len(df_clean)
    logger.info("Removed %d duplicate rows.", removed_count)
    return df_clean


def clean_text_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Strips extra whitespace and standardizes casing for string/text columns.
    """
    df_clean = df.copy()
    str_cols = df_clean.select_dtypes(include=["object"]).columns
    for col in str_cols:
        df_clean[col] = df_clean[col].astype(str).str.strip()
        # Clean specific geographical or category casing
        if col in ["Region", "Category", "Payment_Mode"]:
            df_clean[col] = df_clean[col].str.title()
    return df_clean


def validate_and_convert_dates(df: pd.DataFrame, date_col: str = "Order_Date") -> pd.DataFrame:
    """
    Validates and converts date column to datetime object and sorts chronologically.
    Normalizes slashes and common date separators.
    """
    df_clean = df.copy()
    if date_col not in df_clean.columns:
        raise KeyError(f"Date column '{date_col}' not found in DataFrame.")
        
    # Standardize date string delimiters (e.g. 2023/11/15 -> 2023-11-15)
    normalized_dates = df_clean[date_col].astype(str).str.strip().str.replace("/", "-", regex=False)
    df_clean[date_col] = pd.to_datetime(normalized_dates, errors="coerce")
    
    # Drop records with truly invalid unparseable dates
    invalid_dates = df_clean[date_col].isnull().sum()
    if invalid_dates > 0:
        logger.warning("Dropping %d records with invalid dates in %s", invalid_dates, date_col)
        df_clean = df_clean.dropna(subset=[date_col])
        
    df_clean = df_clean.sort_values(by=date_col).reset_index(drop=True)
    return df_clean


def validate_numeric_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Validates and casts numeric columns to appropriate types.
    """
    df_clean = df.copy()
    numeric_spec = {
        "Sales": float,
        "Quantity": int,
        "Discount": float,
        "Profit": float
    }
    for col, target_type in numeric_spec.items():
        if col in df_clean.columns:
            df_clean[col] = pd.to_numeric(df_clean[col], errors="coerce")
            df_clean = df_clean.dropna(subset=[col])
            df_clean[col] = df_clean[col].astype(target_type)
            
    # Business logic bounds check
    if "Quantity" in df_clean.columns:
        df_clean = df_clean[df_clean["Quantity"] > 0]
    if "Sales" in df_clean.columns:
        df_clean = df_clean[df_clean["Sales"] >= 0]
    if "Discount" in df_clean.columns:
        df_clean["Discount"] = df_clean["Discount"].clip(0.0, 1.0)
        
    return df_clean.reset_index(drop=True)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Creates derived analytical features:
    - Year, Month, Month_Name, Quarter
    - Profit_Margin (% of sales)
    - Sales_Per_Unit
    - Order_Value
    """
    df_eng = df.copy()
    
    # Date derived columns
    df_eng["Year"] = df_eng["Order_Date"].dt.year
    df_eng["Month"] = df_eng["Order_Date"].dt.month
    df_eng["Month_Name"] = df_eng["Order_Date"].dt.strftime("%B")
    df_eng["Quarter"] = "Q" + df_eng["Order_Date"].dt.quarter.astype(str)
    
    # Financial derived metrics
    # Profit Margin = (Profit / Sales) * 100 (Safe division)
    df_eng["Profit_Margin"] = np.where(
        df_eng["Sales"] > 0,
        (df_eng["Profit"] / df_eng["Sales"]) * 100.0,
        0.0
    ).round(2)
    
    # Sales Per Unit = Sales / Quantity
    df_eng["Sales_Per_Unit"] = np.where(
        df_eng["Quantity"] > 0,
        df_eng["Sales"] / df_eng["Quantity"],
        df_eng["Sales"]
    ).round(2)
    
    # Order Value (Row-level transaction sales value)
    df_eng["Order_Value"] = df_eng["Sales"].round(2)
    
    return df_eng


def run_pipeline(raw_filepath: str, output_filepath: str = None) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Executes the end-to-end data preparation pipeline.
    """
    logger.info("Starting Data Engineering Pipeline on: %s", raw_filepath)
    raw_df = load_data(raw_filepath)
    raw_profile = profile_data(raw_df)
    
    # Pipeline steps
    df = handle_missing_values(raw_df)
    df = remove_duplicates(df)
    df = clean_text_columns(df)
    df = validate_and_convert_dates(df, date_col="Order_Date")
    df = validate_numeric_columns(df)
    clean_df = engineer_features(df)
    
    clean_profile = profile_data(clean_df)
    logger.info("Data Engineering Pipeline completed successfully. Clean shape: %s", clean_df.shape)
    
    if output_filepath:
        os.makedirs(os.path.dirname(output_filepath), exist_ok=True)
        # Format Order_Date as YYYY-MM-DD string for clean storage
        export_df = clean_df.copy()
        export_df["Order_Date"] = export_df["Order_Date"].dt.strftime("%Y-%m-%d")
        export_df.to_csv(output_filepath, index=False)
        logger.info("Saved cleaned dataset to %s", output_filepath)
        
    return clean_df, {"raw": raw_profile, "cleaned": clean_profile}


if __name__ == "__main__":
    raw_path = os.path.join("data", "raw_sales_data.csv")
    clean_path = os.path.join("data", "sales_data.csv")
    if os.path.exists(raw_path):
        clean_df, profile = run_pipeline(raw_path, clean_path)
        print("Pipeline execution summary:")
        print(f"Raw records: {profile['raw']['rows']}, Clean records: {profile['cleaned']['rows']}")
    else:
        print(f"Raw data file not found at {raw_path}. Run generate_dataset.py first.")
